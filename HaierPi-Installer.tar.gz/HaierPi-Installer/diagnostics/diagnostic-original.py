import HPi.GPIO as GPIO
import configparser
import serial
import time

config = configparser.ConfigParser()
config.read('config.ini')
loglevel = config['MAIN']['log_level']
modbuspin=config['GPIO']['modbus']
freqlimitpin=config['GPIO']['freqlimit']
heatdemandpin=config['GPIO']['heatdemand']
cooldemandpin=config['GPIO']['cooldemand']
modbusdev=config['MAIN']['modbusdev']

ser = serial.Serial(port=modbusdev, baudrate = 9600, parity=serial.PARITY_EVEN,stopbits=serial.STOPBITS_ONE,bytesize=serial.EIGHTBITS,timeout=2)

GPIO.cleanup(modbuspin)
GPIO.cleanup(freqlimitpin)
GPIO.cleanup(heatdemandpin)
GPIO.cleanup(cooldemandpin)
GPIO.setup(modbuspin, GPIO.OUT) #modbus
GPIO.setup(freqlimitpin, GPIO.OUT) #freq limit
GPIO.setup(heatdemandpin, GPIO.OUT) # heat demand
GPIO.setup(cooldemandpin, GPIO.OUT) # cool demand

print("===== Program diagnostyczny =====")
print("\n\nPrzed rozpoczÄ™ciem diagnostyki, upewnij siÄ™Â Å¼e usÅ‚uga haier jest wyÅ‚Ä…czona\n\nWykonaj polecenie jako root: systemctl stop haier\n\n")
tcn=input("Czy chcesz wÅ‚Ä…czyÄ‡ diagnostykÄ™? T/N ")
if tcn == "T": 
    if modbuspin == "0" or modbuspin == "17":
        GPIO.output(modbuspin, GPIO.HIGH)
        time.sleep(2)
        GPIO.output(modbuspin, GPIO.LOW)
        iwmodbus=input("1. Czy byÅ‚y sÅ‚yszalne 2 klikniÄ™cia przekaÅºnikiem? T/N ")
    else:
        print("Prawdopodobnie Åºle skonfigurowany GPIO dla modbus, jest:"+str(modbuspin)+", powinien byÄ‡: 0 dla Nano Pi NEO, lub 17 dla Raspberry Pi zero")

    if freqlimitpin == "64" or freqlimitpin == "27":
        GPIO.output(freqlimitpin, GPIO.HIGH)
        time.sleep(2)
        GPIO.output(freqlimitpin, GPIO.LOW)
        iwfreqlimit=input("2. Czy byÅ‚y sÅ‚yszalne 2 klikniÄ™cia przekaÅºnikiem? T/N ")
    else:
        print("Prawdopodobnie Åºle skonfigurowany GPIO dla freqlimit, jest:"+str(freqlimitpin)+", powinien byÄ‡: 64 dla Nano Pi NEO, lub 27 dla Raspberry Pi zero")

    if heatdemandpin == "2" or heatdemandpin == "22":
        GPIO.output(heatdemandpin, GPIO.HIGH)
        time.sleep(2)
        GPIO.output(heatdemandpin, GPIO.LOW)
        iwheatdemand=input("3. Czy byÅ‚y sÅ‚yszalne 2 klikniÄ™cia przekaÅºnikiem? T/N ")
    else:
        print("Prawdopodobnie Åºle skonfigurowany GPIO dla heatdemand, jest:"+str(heatdemandpin)+", powinien byÄ‡: 2 dla Nano Pi NEO, lub 22 dla Raspberry Pi zero")

    if cooldemandpin == "3" or cooldemandpin == "10":
        GPIO.output(cooldemandpin, GPIO.HIGH)
        time.sleep(2)
        GPIO.output(cooldemandpin, GPIO.LOW)
        iwcooldemand=input("4. Czy byÅ‚y sÅ‚yszalne 2 klikniÄ™cia przekaÅºnikiem? T/N ")
    else:
        print("Prawdopodobnie Åºle skonfigurowany GPIO dla cooldemand, jest:"+str(cooldemandpin)+", powinien byÄ‡: 3 dla Nano Pi NEO, lub 10 dla Raspberry Pi zero")


    if iwmodbus == "N":
        print("CoÅ› nie tak ze sterowaniem przekaÅºnikiem od MODBUS")
    if iwfreqlimit == "N":
        print("CoÅ› nie tak ze sterowaniem przekaÅºnikiem od FREQLIMIT")
    if iwheatdemand == "N":
        print("CoÅ› nie tak ze sterowaniem przekaÅºnikiem od HEATDEMAND")
    if iwcooldemand == "N":
        print("CoÅ› nie tak ze sterowaniem przekaÅºnikiem od COOLDEMAND")

    print("NastÄ™pny etap do odczyt danych modbus")
    tcn2=input("Czy jesteÅ› gotowy? T/N ")
    if tcn2 == "T":
        if modbusdev == "/dev/ttyS1" or modbusdev == "/dev/ttyAMA0":
            print("CZYTAM MODBUS")
            rs = ser.read(200).hex()
            if len(str(rs)) > 1:
                print("odczytaÅ‚em:"+str(len(str(rs)))+" BajtÃ³w")
                tcnshow=input("Czy wyÅ›wietliÄ‡ odczytanÄ… zawartoÅ›Ä‡? T/N ")
                if tcnshow == "T":
                    print(rs)
            else:
                print("NastÄ…piÅ‚ timeout odczytu danych, nie odczytano Å¼adnych danych\nPrawdopodobne uszkodzenie ukÅ‚adu transceivera rs485")
        else:
            print("Prawdopodobnie Åºle skonfigurowane urzÄ™dzenie modbusdev, jest:"+str(modbusdev)+" powinno byÄ‡ /dev/ttyS1 dla NanoPi NEO lub /dev/ttyAMA0 dla RaspberryPi zero")
    else:
        print("OK... koÅ„czÄ™")

    print("=========== KONIEC DIAGNOSTYKI =========")
else:
    print("NOTHING")


GPIO.cleanup(modbuspin)
GPIO.cleanup(freqlimitpin)
GPIO.cleanup(heatdemandpin)
GPIO.cleanup(cooldemandpin)
