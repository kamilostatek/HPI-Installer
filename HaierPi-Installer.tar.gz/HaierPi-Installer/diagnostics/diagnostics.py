#!/usr/bin/env python3
"""Diagnostyka HPI: testy przekaznikow + odczyt Modbus.

Wersja ostrozniejsza oparta na diagnostic.py dostarczonym przez uzytkownika.
Nie uruchamiac przy dzialajacej usludze haier.service.
"""
import configparser
from pathlib import Path
import sys
import time

CFG = Path('/opt/config.ini')
EXPECTED = {
    '/dev/ttyS1': {'modbus': 0, 'freqlimit': 64, 'heatdemand': 2, 'cooldemand': 3},
    '/dev/ttyAMA0': {'modbus': 17, 'freqlimit': 27, 'heatdemand': 22, 'cooldemand': 10},
}


def ask(question):
    try:
        return input(question + ' [T/N]: ').strip().upper() == 'T'
    except EOFError:
        return False


def main():
    print('\n=== DIAGNOSTYKA HAIERPI ===')
    print('UWAGA: test przelacza rzeczywiste wyjscia GPIO i moze uruchomic przekazniki.')
    print('Usluga haier.service musi byc zatrzymana. Sprawdz polaczenia z pompa.')
    if not CFG.is_file():
        raise RuntimeError('Brak /opt/config.ini')
    config = configparser.ConfigParser()
    config.read(CFG, encoding='utf-8')
    device = config.get('MAIN', 'modbusdev').strip()
    if device not in EXPECTED:
        raise RuntimeError(f'Nieobslugiwane urzadzenie Modbus: {device}')
    expected = EXPECTED[device]
    actual = {name: config.getint('GPIO', name) for name in expected}
    invalid = [f'{name}: {actual[name]} (oczekiwano {value})' for name, value in expected.items()
               if actual[name] != value]
    if invalid:
        print('BLEDNA KONFIGURACJA GPIO:')
        for issue in invalid:
            print('  ' + issue)
        print('Przerwano bez dotykania wyjsc GPIO.')
        return 1
    print(f'Port Modbus: {device}; GPIO: {actual}')
    if not ask('Czy rozpoczac testy GPIO?'):
        print('Anulowano bez dotykania wyjsc GPIO.')
        return 0

    import HPi.GPIO as GPIO
    configured = []
    try:
        for name in ['modbus', 'freqlimit', 'heatdemand', 'cooldemand']:
            pin = actual[name]
            print(f'\nTest {name.upper()} na GPIO {pin}.')
            if not ask('Przelaczyc ten przekaznik na 2 sekundy?'):
                continue
            GPIO.setup(pin, GPIO.OUT)
            configured.append(pin)
            GPIO.output(pin, GPIO.HIGH)
            try:
                time.sleep(2)
            finally:
                GPIO.output(pin, GPIO.LOW)
            if ask('Czy slyszales dwa klikniecia przekaznika?'):
                print('Odpowiedz: TAK')
            else:
                print('UWAGA: nie potwierdzono dwoch klikniec.')
    finally:
        for pin in reversed(configured):
            try:
                GPIO.output(pin, GPIO.LOW)
            except Exception as exc:
                print(f'UWAGA: nie ustawiono LOW na GPIO {pin}: {exc}', file=sys.stderr)
            try:
                GPIO.cleanup(pin)
            except Exception as exc:
                print(f'UWAGA: nie zwolniono GPIO {pin}: {exc}', file=sys.stderr)

    if ask('Czy wykonac odczyt surowych danych Modbus RS485?'):
        import serial
        print('Otwieram port Modbus (9600, 8E1, timeout 2 s)...')
        try:
            with serial.Serial(port=device, baudrate=9600, parity=serial.PARITY_EVEN,
                               stopbits=serial.STOPBITS_ONE, bytesize=serial.EIGHTBITS,
                               timeout=2) as port:
                payload=port.read(200)
        except Exception as exc:
            print('Blad portu Modbus:', exc)
            return 1
        if payload:
            print(f'Odebrano {len(payload)} bajtow.')
            if ask('Pokazac dane w hex?'):
                print(payload.hex())
        else:
            print('Timeout: nie odebrano danych. Nie oznacza to automatycznie awarii RS485.')
    print('\n=== KONIEC DIAGNOSTYKI ===')
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (KeyError, ValueError, OSError, RuntimeError) as exc:
        print('BLAD DIAGNOSTYKI:', exc, file=sys.stderr)
        sys.exit(1)
