# Patched GetState: decodes state by bit flags (handles pump/heater force bits)
# and keeps legacy output strings used by HaierPi.


def GetState(payload):
    """Mode display function.

    Expected payload length is 6. Uses low byte of R101[0].

    Bits used:
      - bit0 (0x01): ON/OFF
      - bit1 (0x02): COOL request
      - bit2 (0x04): HEAT request
      - bit7 (0x80): TANK request

    Other bits (e.g. pump 0x20, heater 0x08) are ignored for the textual state.
    """

    if len(payload) != 6:
        return "Bad payload length"

    state = int(payload[0]) & 0xFF

    onoff = "ON" if (state & 0x01) else "OFF"
    tank = bool(state & 0x80)
    is_cool = bool(state & 0x02)
    is_heat = bool(state & 0x04)

    # If both COOL and HEAT bits are set, treat it as "no heat/cool" (commonly Tank-only).
    mode = ""
    if is_cool and not is_heat:
        mode = "Cool"
    elif is_heat and not is_cool:
        mode = "Heat"

    if mode and tank:
        return f"{mode}+Tank {onoff}"
    if mode:
        return f"{mode} {onoff}"
    if tank:
        return f"Tank {onoff}"
    return onoff
