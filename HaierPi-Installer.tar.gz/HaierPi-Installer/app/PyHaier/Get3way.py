def Get3way(payload):
    """
    Function for displaying 3-way valve / active circuit state.
    payload - register from 141 to 157
    :return: 'DHW', 'CH', '' or 'Bad payload length'

    Observed mapping for R141[0] / v4:
       0 / 0x000 = no active circuit / N.A.
     512 / 0x200 = CH state observed during cooling
    1024 / 0x400 = CH state observed during heating
    1536 / 0x600 = DHW-priority state observed during DHW heating

    Important: R141[0] looks like active/logical circuit state, not a simple physical valve end-position.
    """
    if len(payload) == 16:
        raw = payload[0]
        bit512 = bool(raw & 512)
        bit1024 = bool(raw & 1024)

        if bit512 and bit1024:
            threeway = 'DHW'
        elif bit512 or bit1024:
            threeway = 'CH'
        else:
            threeway = ''

        return threeway
    else:
        return "Bad payload length"
