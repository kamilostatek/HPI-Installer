"""Offline scheduler regression tests.

Run from the application directory with:
    python3 -m unittest discover -s tests -v

The application module is deliberately NOT imported: it initializes GPIO,
serial communications and background services at import time. Selected
scheduler functions are compiled from its AST and run against local fakes.
"""
import ast
import copy
from datetime import datetime
import json
import logging
import math
import os
from pathlib import Path
import re
import tempfile
import threading
from types import SimpleNamespace
import unittest
from unittest.mock import Mock, patch

PROJECT = Path(__file__).resolve().parents[1]


def load_schedule_rules():
    """Compile only the pure scheduling definitions embedded in main.py.

    No application imports or top-level startup statements are executed. The
    explicit allowlist also makes missing or duplicate definitions fail early.
    """
    names = {
        'ScheduleValidationError', 'temperature_settings', 'empty_schedule',
        '_minutes', '_time_text', '_number', '_temperature_in_range',
        '_legacy_temperature', 'period_temperature', 'validate_schedule',
        'active_period',
    }
    constant = 'SCHEDULE_STEP_MINUTES'
    tree = ast.parse((PROJECT / 'main.py').read_text(encoding='utf-8'))
    nodes = []
    found = []
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.ClassDef)) and node.name in names:
            nodes.append(node)
            found.append(node.name)
        elif (isinstance(node, ast.Assign) and len(node.targets) == 1
              and isinstance(node.targets[0], ast.Name)
              and node.targets[0].id == constant):
            # The sole selected assignment must be a literal, not a startup call.
            ast.literal_eval(node.value)
            nodes.append(node)
            found.append(constant)
    expected = names | {constant}
    if set(found) != expected or len(found) != len(expected):
        raise RuntimeError('Missing or duplicate scheduling definitions in main.py')
    namespace = {'math': math, 're': re, '__name__': 'scheduler_rules_test'}
    exec(compile(ast.Module(body=nodes, type_ignores=[]), 'scheduler-rules', 'exec'), namespace)
    return SimpleNamespace(**{name: namespace[name] for name in expected})


logic = load_schedule_rules()


def week(*periods, day=0):
    result = [{'day': index, 'periods': []} for index in range(7)]
    result[day]['periods'] = list(periods)
    return result


def period(start='06:00', end='08:00', **extra):
    return dict(start=start, end=end, title='', **extra)


class ScheduleLogicTests(unittest.TestCase):
    def setUp(self):
        self.settings = logic.temperature_settings('auto', '0')

    def validate(self, data, which='ch'):
        return logic.validate_schedule(data, which, self.settings)

    def test_curve_direct_and_dhw_have_distinct_units_and_resolution(self):
        direct = logic.temperature_settings('directly', '0')
        expert = logic.temperature_settings('directly', '1')
        self.assertEqual(self.settings['ch']['target'], 'room')
        self.assertEqual(self.settings['ch']['step'], 0.1)
        self.assertEqual(direct['ch']['target'], 'water')
        self.assertEqual(direct['ch']['step'], 0.5)
        self.assertEqual((direct['ch']['min'], direct['ch']['max']), (25, 55))
        self.assertEqual(expert['ch']['min'], 20)
        self.assertEqual((self.settings['dhw']['min'], self.settings['dhw']['max']), (30, 55))
        self.assertEqual(self.settings['dhw']['step'], 0.5)

    def test_calendar_days_use_day_identifier_not_input_position(self):
        data = week(period(temperature=21, temperature_target='room'), day=2)
        data.reverse()
        normalized = self.validate(data)
        self.assertIsNotNone(logic.active_period(normalized, datetime(2026, 10, 28, 7)))
        self.assertIsNone(logic.active_period(normalized, datetime(2026, 10, 26, 7)))

    def test_adjacent_period_switches_exactly_at_boundary(self):
        data = self.validate(week(
            period('06:00', '08:00', temperature=21, temperature_target='room'),
            period('08:00', '10:00', temperature=19, temperature_target='room'),
        ))
        self.assertEqual(logic.active_period(data, datetime(2026, 10, 26, 7, 59, 59))['temperature'], 21)
        self.assertEqual(logic.active_period(data, datetime(2026, 10, 26, 8))['temperature'], 19)
        self.assertIsNone(logic.active_period(data, datetime(2026, 10, 26, 10)))

    def test_start_is_inclusive_and_end_is_exclusive(self):
        data = self.validate(week(period()))
        self.assertIsNone(logic.active_period(data, datetime(2026, 10, 26, 5, 59, 59)))
        self.assertIsNotNone(logic.active_period(data, datetime(2026, 10, 26, 6)))
        self.assertIsNone(logic.active_period(data, datetime(2026, 10, 26, 8)))

    def test_legacy_end_midnight_and_24_hour_end_are_equivalent(self):
        for end in ('00:00', '24:00'):
            with self.subTest(end=end):
                data = self.validate(week(period('22:00', end)))
                self.assertIsNotNone(logic.active_period(data, datetime(2026, 10, 26, 23, 59, 59)))
                self.assertIsNone(logic.active_period(data, datetime(2026, 10, 27, 0)))

    def test_legacy_zero_to_zero_is_full_day(self):
        data = self.validate(week(period('00:00', '00:00')))
        self.assertIsNotNone(logic.active_period(data, datetime(2026, 10, 26, 0)))
        self.assertIsNotNone(logic.active_period(data, datetime(2026, 10, 26, 23, 59)))

    def test_sunday_to_monday_uses_new_weekday(self):
        data = week(period('00:00', '02:00', temperature=20, temperature_target='room'))
        data[6]['periods'] = [period('22:00', '24:00', temperature=22, temperature_target='room')]
        data = self.validate(data)
        self.assertEqual(logic.active_period(data, datetime(2026, 11, 1, 23, 59))['temperature'], 22)
        self.assertEqual(logic.active_period(data, datetime(2026, 11, 2, 0))['temperature'], 20)

    def test_empty_week_has_no_active_period(self):
        self.assertIsNone(logic.active_period(self.validate(week()), datetime(2026, 10, 26, 7)))

    def test_overlaps_are_rejected_without_rejecting_adjacency(self):
        for start, end in [('07:00', '09:00'), ('06:00', '08:00'), ('05:00', '09:00')]:
            with self.subTest(start=start, end=end):
                with self.assertRaises(logic.ScheduleValidationError):
                    self.validate(week(period(), period(start, end)))
        self.validate(week(period(), period('08:00', '09:00')))

    def test_invalid_times_are_rejected(self):
        for start, end in [('25:00', '26:00'), ('07:60', '09:00'), ('08:00', '08:00'),
                           ('22:00', '06:00'), ('6pm', '20:00'), ('24:00', '24:00')]:
            with self.subTest(start=start, end=end):
                with self.assertRaises(logic.ScheduleValidationError):
                    self.validate(week(period(start, end)))

    def test_save_rejects_times_that_the_half_hour_editor_cannot_preserve(self):
        for start, end in [('06:15', '08:00'), ('06:00', '08:10')]:
            with self.subTest(start=start, end=end):
                with self.assertRaises(logic.ScheduleValidationError):
                    self.validate(week(period(start, end)))

    def test_duplicate_or_invalid_weekday_is_rejected(self):
        for day in (-1, 7, True, 'Monday'):
            with self.subTest(day=day):
                data = week()
                data[0]['day'] = day
                with self.assertRaises(logic.ScheduleValidationError):
                    self.validate(data)
        data = week()
        data[1]['day'] = 0
        with self.assertRaises(logic.ScheduleValidationError):
            self.validate(data)

    def test_temperature_range_step_and_nonfinite_values_are_rejected(self):
        cases = [('ch', 31), ('ch', 21.25), ('ch', True), ('ch', float('nan')),
                 ('ch', float('inf')), ('ch', 'not a temperature'), ('dhw', 56),
                 ('dhw', 29), ('dhw', 45.25)]
        for which, value in cases:
            with self.subTest(which=which, value=value):
                target = 'room' if which == 'ch' else 'dhw'
                with self.assertRaises(logic.ScheduleValidationError):
                    self.validate(week(period(temperature=value, temperature_target=target)), which)

    def test_valid_dhw_half_degree_setpoint_is_preserved(self):
        data = self.validate(week(period(temperature=45.5, temperature_target='dhw')), 'dhw')
        actual = logic.period_temperature(data[0]['periods'][0], 'dhw', self.settings)
        self.assertEqual(actual, 45.5)

    def test_old_numeric_ch_title_remains_usable_as_target(self):
        old = {'start': '06:00', 'end': '08:00', 'title': '21.5'}
        data = self.validate(week(old))
        self.assertEqual(logic.period_temperature(data[0]['periods'][0], 'ch', self.settings), 21.5)

    def test_old_descriptive_title_and_dhw_numeric_title_are_not_temperatures(self):
        old = {'start': '06:00', 'end': '08:00', 'title': 'Morning'}
        self.assertIsNone(logic.period_temperature(old, 'ch', self.settings))
        old['title'] = '45'
        self.assertIsNone(logic.period_temperature(old, 'dhw', self.settings))

    def test_explicit_blank_does_not_reactivate_legacy_title(self):
        old = {'start': '06:00', 'end': '08:00', 'title': '21', 'temperature': None}
        data = self.validate(week(old))
        self.assertIsNone(logic.period_temperature(data[0]['periods'][0], 'ch', self.settings))

    def test_mode_switch_does_not_reinterpret_water_as_room_target(self):
        water = period(temperature=30, temperature_target='water')
        self.assertIsNone(logic.period_temperature(water, 'ch', self.settings))
        with self.assertRaises(logic.ScheduleValidationError):
            self.validate(week(water))
        direct = logic.temperature_settings('directly', '0')
        room = period(temperature=28, temperature_target='room')
        self.assertIsNone(logic.period_temperature(room, 'ch', direct))

    def test_validation_does_not_mutate_caller_schedule(self):
        original = week(period(temperature='21.5', temperature_target='room'))
        before = copy.deepcopy(original)
        self.validate(original)
        self.assertEqual(original, before)


class FrozenDateTime(datetime):
    current = datetime(2026, 10, 26, 7)

    @classmethod
    def now(cls, tz=None):
        return cls.current


def scheduler_namespace():
    """Load only scheduling function bodies; all device operations are fakes."""
    tree = ast.parse((PROJECT / 'main.py').read_text(encoding='utf-8'))
    selected_names = {
        'schedule_write', '_load_schedule', '_scheduler_config',
        '_schedule_temperature_equal', '_schedule_ch_mode_ready', '_schedule_ch_inputs_ready',
        '_run_circuit_schedule', 'scheduler',
    }
    nodes = [node for node in tree.body
             if isinstance(node, ast.FunctionDef) and node.name in selected_names]
    namespace = {
        'json': json, 'os': os, 'math': math, 'tempfile': tempfile,
        'threading': threading, 'logging': Mock(spec=logging),
        'datetime': FrozenDateTime, 'gettext': lambda message: message,
        'heatingcurve': 'auto', 'expert_mode': '0',
        'last_heatingcurve_mode': 'auto',
        'chscheduler': '1', 'dhwscheduler': '1',
        'dhw_ondemand_active': False, 'dhw_ondemand_lock': threading.Lock(),
        'anti_legionella_active': False, 'anti_legionella_run': '0',
        'statusdict': {
            'pch': {'value': 'on'}, 'pdhw': {'value': 'on'},
            'pcool': {'value': 'off'}, 'defrost': {'value': 'off'},
            'settemp': {'value': 20}, 'dhw': {'value': 40},
            'hcurve': {'value': 35},
            'intemp': {'value': 20}, 'outtemp': {'value': 5},
        },
    }
    namespace.update({name: getattr(logic, name) for name in dir(logic)
                      if not name.startswith('_')})
    # Keep the deterministic test clock if the pure module exports datetime.
    namespace['datetime'] = FrozenDateTime
    exec(compile(ast.Module(body=nodes, type_ignores=[]), 'scheduler-functions', 'exec'), namespace)
    return namespace


class SchedulerIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.ns = scheduler_namespace()
        self.data = {
            'ch': week(period(temperature=21, temperature_target='room')),
            'dhw': week(period(temperature=45.5, temperature_target='dhw')),
        }
        self.ns['_load_schedule'] = Mock(side_effect=lambda which: self.data[which])

        def change_state(mode, value, source):
            if mode == 'off':
                self.ns['statusdict']['pch']['value'] = 'off'
                self.ns['statusdict']['pcool']['value'] = 'off'
            else:
                self.ns['statusdict'][mode]['value'] = value
            return 'OK'

        def change_temperature(which, value, curve):
            key = 'settemp' if which == 'heat' else 'dhw'
            self.ns['statusdict'][key]['value'] = float(value)
            return which, True

        def calculate_curve(**kwargs):
            self.ns['last_heatingcurve_mode'] = self.ns['heatingcurve']
            return self.ns['statusdict']['hcurve']['value']

        self.ns['statechange'] = Mock(side_effect=change_state)
        self.ns['new_tempchange'] = Mock(side_effect=change_temperature)
        self.ns['curvecalc'] = Mock(side_effect=calculate_curve)

    def tick(self):
        self.ns['scheduler']()

    def temp_calls(self, which):
        return [call.args for call in self.ns['new_tempchange'].call_args_list if call.args[0] == which]

    def state_calls(self, which):
        return [call.args for call in self.ns['statechange'].call_args_list if call.args[0] == which]

    def test_co_and_cwu_setpoints_use_the_correct_command_paths(self):
        self.tick()
        ch = self.temp_calls('heat')
        dhw = self.temp_calls('dhw')
        self.assertEqual(len(ch), 1)
        self.assertEqual((float(ch[0][1]), ch[0][2]), (21, '0'))
        self.assertEqual(len(dhw), 1)
        self.assertEqual((float(dhw[0][1]), dhw[0][2]), (45.5, '1'))
        self.ns['curvecalc'].assert_called_once()

    def test_repeated_tick_does_not_repeat_temperature_writes(self):
        self.tick()
        self.tick()
        self.assertEqual(len(self.temp_calls('heat')), 1)
        self.assertEqual(len(self.temp_calls('dhw')), 1)

    def test_equal_numeric_setpoints_do_not_write_when_types_differ(self):
        self.ns['statusdict']['settemp']['value'] = '21.0'
        self.ns['statusdict']['dhw']['value'] = '45.50'
        self.tick()
        self.ns['new_tempchange'].assert_not_called()

    def test_blank_temperature_retains_on_off_control_without_setpoint_change(self):
        self.data['ch'] = week(period(temperature=None))
        self.data['dhw'] = week(period(temperature=None))
        self.ns['statusdict']['pch']['value'] = 'off'
        self.ns['statusdict']['pdhw']['value'] = 'off'
        self.tick()
        self.assertIn(('pch', 'on', '1'), self.state_calls('pch'))
        self.assertIn(('pdhw', 'on', '1'), self.state_calls('pdhw'))
        self.ns['new_tempchange'].assert_not_called()

    def test_outside_periods_stops_each_requested_circuit(self):
        self.data = {'ch': week(), 'dhw': week()}
        self.tick()
        self.assertEqual(self.ns['statusdict']['pch']['value'], 'off')
        self.assertEqual(self.ns['statusdict']['pdhw']['value'], 'off')
        self.ns['new_tempchange'].assert_not_called()

    def test_disabled_schedulers_issue_no_commands(self):
        self.ns['chscheduler'] = '0'
        self.ns['dhwscheduler'] = '0'
        self.tick()
        self.ns['statechange'].assert_not_called()
        self.ns['new_tempchange'].assert_not_called()
        self.ns['_load_schedule'].assert_not_called()

    def test_each_dhw_override_blocks_both_dhw_state_and_temperature(self):
        cases = [('dhw_ondemand_active', True), ('anti_legionella_active', True), ('anti_legionella_run', '1')]
        for name, value in cases:
            with self.subTest(override=name):
                self.setUp()
                self.ns[name] = value
                self.ns['statusdict']['pdhw']['value'] = 'off'
                self.tick()
                self.assertEqual(self.temp_calls('dhw'), [])
                self.assertEqual(self.state_calls('pdhw'), [])
                self.assertEqual(len(self.temp_calls('heat')), 1)

    def test_broken_ch_schedule_does_not_block_dhw(self):
        self.data['ch'] = None
        self.tick()
        self.assertEqual(self.temp_calls('heat'), [])
        self.assertEqual(self.state_calls('pch'), [])
        self.assertEqual(len(self.temp_calls('dhw')), 1)

    def test_broken_dhw_schedule_leaves_dhw_state_untouched(self):
        self.data['dhw'] = None
        self.tick()
        self.assertEqual(self.temp_calls('dhw'), [])
        self.assertEqual(self.state_calls('pdhw'), [])
        self.assertEqual(len(self.temp_calls('heat')), 1)

    def test_ch_command_exception_does_not_block_dhw(self):
        original = self.ns['new_tempchange'].side_effect
        def failing_change(which, value, curve):
            if which == 'heat':
                raise RuntimeError('simulated CH command failure')
            return original(which, value, curve)
        self.ns['new_tempchange'].side_effect = failing_change
        self.tick()
        self.assertEqual(len(self.temp_calls('dhw')), 1)

    def test_mode_mismatch_keeps_time_control_but_does_not_apply_wrong_units(self):
        self.data['ch'] = week(period(temperature=30, temperature_target='water'))
        self.ns['statusdict']['pch']['value'] = 'off'
        self.tick()
        self.assertEqual(self.temp_calls('heat'), [])
        self.assertIn(('pch', 'on', '1'), self.state_calls('pch'))

    def test_unconfirmed_dhw_write_is_retried_from_actual_pump_status(self):
        original = self.ns['new_tempchange'].side_effect
        def change(which, value, source):
            if which == 'dhw':
                return 'DHW timeout', False
            return original(which, value, source)
        self.ns['new_tempchange'].side_effect = change
        self.tick()
        self.tick()
        self.assertEqual(len(self.temp_calls('dhw')), 2)
        self.assertEqual(len(self.temp_calls('heat')), 1)
        self.assertEqual(self.ns['statusdict']['dhw']['value'], 40)

    def test_deferred_direct_transition_does_not_apply_target_in_wrong_mode(self):
        self.ns['heatingcurve'] = 'directly'
        self.data['ch'] = week(period(temperature=40, temperature_target='water'))
        self.ns['statusdict']['pch']['value'] = 'off'
        self.ns['curvecalc'].side_effect = lambda **kwargs: None
        self.tick()
        self.assertEqual(self.temp_calls('heat'), [])
        self.assertEqual(self.ns['last_heatingcurve_mode'], 'auto')
        self.assertIn(('pch', 'on', '1'), self.state_calls('pch'))

    def test_ending_co_period_does_not_disable_cooling(self):
        self.ns['statusdict']['pcool']['value'] = 'on'
        self.data['ch'] = week()
        self.tick()
        self.assertEqual(self.ns['statusdict']['pch']['value'], 'off')
        self.assertEqual(self.ns['statusdict']['pcool']['value'], 'on')
        self.assertNotIn(('off', 'off', '1'), [call.args for call in self.ns['statechange'].call_args_list])

    def test_target_deferred_by_defrost_is_applied_on_first_ready_tick(self):
        self.ns['statusdict']['defrost']['value'] = 'on'
        self.tick()
        self.ns['curvecalc'].assert_not_called()
        self.assertEqual(self.ns['statusdict']['settemp']['value'], 21)
        self.ns['statusdict']['defrost']['value'] = 'off'
        self.tick()
        self.ns['curvecalc'].assert_called_once_with(force_setpoint=True)
        self.assertEqual(len(self.temp_calls('heat')), 1)

    def test_delayed_co_start_does_not_cache_curve_before_confirmed_on(self):
        self.ns['statusdict']['pch']['value'] = 'off'
        self.ns['statechange'].side_effect = lambda *args: 'OK'
        self.tick()
        self.ns['curvecalc'].assert_not_called()
        self.ns['statusdict']['pch']['value'] = 'on'
        self.tick()
        self.ns['curvecalc'].assert_called_once_with(force_setpoint=True)
        self.assertEqual(len(self.temp_calls('heat')), 1)

    def test_missing_curve_input_defers_apply_until_first_valid_reading(self):
        self.ns['statusdict']['intemp']['value'] = 'N.A.'
        self.tick()
        self.ns['curvecalc'].assert_not_called()
        self.ns['statusdict']['intemp']['value'] = 20
        self.tick()
        self.ns['curvecalc'].assert_called_once_with(force_setpoint=True)
        self.assertEqual(len(self.temp_calls('heat')), 1)

    def test_failed_config_save_is_retried_even_if_in_memory_target_changed(self):
        original = self.ns['new_tempchange'].side_effect
        attempts = []
        def change(which, value, source):
            result = original(which, value, source)
            if which == 'heat':
                attempts.append(value)
                if len(attempts) == 1:
                    return 'config save failed', False
            return result
        self.ns['new_tempchange'].side_effect = change
        self.tick()
        self.assertEqual(self.ns['statusdict']['settemp']['value'], 21)
        self.tick()
        self.tick()
        self.assertEqual(len(attempts), 2)
        self.assertIsNone(self.ns.get('_schedule_ch_pending'))

    def test_unconfirmed_forced_curve_write_remains_pending_for_retry(self):
        self.ns['curvecalc'].side_effect = [None, 35]
        self.tick()
        self.assertIsNotNone(self.ns.get('_schedule_ch_pending'))
        self.tick()
        self.assertEqual(self.ns['curvecalc'].call_count, 2)
        self.assertIsNone(self.ns.get('_schedule_ch_pending'))
        self.assertEqual(len(self.temp_calls('heat')), 1)

    def test_changed_period_discards_pending_target_even_if_new_value_is_already_set(self):
        self.ns['statusdict']['defrost']['value'] = 'on'
        self.tick()
        self.assertIsNotNone(self.ns.get('_schedule_ch_pending'))
        self.data['ch'] = week(period(temperature=20, temperature_target='room'))
        self.ns['statusdict']['settemp']['value'] = 20
        self.ns['statusdict']['defrost']['value'] = 'off'
        self.tick()
        self.assertIsNone(self.ns.get('_schedule_ch_pending'))
        self.ns['curvecalc'].assert_not_called()

    def test_direct_entry_initializes_mode_before_applying_water_setpoint(self):
        self.ns['heatingcurve'] = 'directly'
        self.data['ch'] = week(period(temperature=40, temperature_target='water'))
        events = []
        original_curve = self.ns['curvecalc'].side_effect
        original_change = self.ns['new_tempchange'].side_effect
        def curve(**kwargs):
            events.append('initialize_or_apply')
            return original_curve(**kwargs)
        def change(which, value, source):
            events.append(which)
            return original_change(which, value, source)
        self.ns['curvecalc'].side_effect = curve
        self.ns['new_tempchange'].side_effect = change
        self.tick()
        self.assertEqual(events[0], 'initialize_or_apply')
        self.assertEqual(self.ns['statusdict']['settemp']['value'], 40)
        self.assertEqual(self.ns['last_heatingcurve_mode'], 'directly')


def load_app_function(namespace, name):
    tree = ast.parse((PROJECT / 'main.py').read_text(encoding='utf-8'))
    node = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == name)
    exec(compile(ast.Module(body=[node], type_ignores=[]), 'app-function', 'exec'), namespace)


class CurveApplicationTests(unittest.TestCase):
    """Exercise the real Direct branch with GPIO and pump writes mocked."""
    def setUp(self):
        self.ns = scheduler_namespace()
        self.ns.update({
            'heatingcurve': 'directly', 'last_heatingcurve_mode': 'directly',
            'saved_settemp_before_direct': None, 'thermostat_on': '0',
            'heatdemand_hi_since': None, 'cooldemand_lo_since': None,
            'heatdemandpin': 1, 'cooldemandpin': 2,
            'GPIO': Mock(), 'gpiocontrol': Mock(),
            'get_temp_zone': lambda value: 'normal',
            '_tempzone_flimit_restore_guard': Mock(),
            'flimit': 'off', 'presetautochange': 'manual', 'antionoff': '0',
            'isfloat': lambda value: isinstance(value, (int, float)),
            'new_tempchange': Mock(return_value=('CH', True)),
        })
        self.ns['GPIO'].input.return_value = 0
        self.ns['statusdict']['settemp']['value'] = 40.0
        self.ns['statusdict']['hcurve']['value'] = 40.0
        def publish(key, value):
            self.ns['statusdict'].setdefault(key, {})['value'] = value
        self.ns['ischanged'] = Mock(side_effect=publish)
        load_app_function(self.ns, 'curvecalc')

    def test_forced_direct_apply_writes_even_when_curve_is_already_cached(self):
        result = self.ns['curvecalc'](force_setpoint=True)
        self.assertEqual(result, 40)
        self.ns['new_tempchange'].assert_called_once_with('heat', 40.0, '1')
        self.ns['logging'].exception.assert_not_called()

    def test_failed_forced_direct_write_returns_no_confirmation(self):
        self.ns['new_tempchange'].return_value = ('CH timeout', False)
        result = self.ns['curvecalc'](force_setpoint=True)
        self.assertIsNone(result)
        self.ns['new_tempchange'].assert_called_once_with('heat', 40.0, '1')
        self.ns['logging'].exception.assert_not_called()

    def test_forced_direct_apply_with_missing_target_is_not_confirmed_from_cached_curve(self):
        self.ns['statusdict']['settemp']['value'] = 'N.A.'
        result = self.ns['curvecalc'](force_setpoint=True)
        self.assertIsNone(result)
        self.ns['new_tempchange'].assert_not_called()

    def test_ch_target_update_with_discovery_does_not_require_optional_number_object(self):
        load_app_function(self.ns, 'new_tempchange')
        self.ns['ha_mqtt_discovery'] = '1'
        self.ns['saveconfig'] = Mock(return_value=True)
        self.ns['queue_pub'] = Mock()
        self.ns.pop('Settemp_number', None)
        _, confirmed = self.ns['new_tempchange']('heat', 21.5, '0')
        self.assertTrue(confirmed)
        self.ns['saveconfig'].assert_called_once_with('SETTINGS', 'settemp', 21.5)
        self.ns['queue_pub'].assert_called_once_with('settemp', 21.5)


class ScheduleStorageTests(unittest.TestCase):
    def setUp(self):
        self.ns = scheduler_namespace()
        self.directory = tempfile.TemporaryDirectory()
        self.previous_cwd = Path.cwd()
        os.chdir(self.directory.name)
        self.original = json.dumps(week(period(temperature=21, temperature_target='room')))
        Path('schedule_ch.json').write_text(self.original, encoding='utf-8')

    def tearDown(self):
        os.chdir(self.previous_cwd)
        self.directory.cleanup()

    def test_invalid_save_never_replaces_previous_file(self):
        invalid = [
            '{broken json',
            json.dumps(week(period(temperature=99, temperature_target='room'))),
            json.dumps(week(period(), period('07:00', '09:00'))),
            json.dumps(week(period(temperature=float('nan'), temperature_target='room'))),
        ]
        for data in invalid:
            with self.subTest(data=data):
                _, state = self.ns['schedule_write']('ch', data)
                self.assertNotEqual(state, 'success')
                self.assertEqual(Path('schedule_ch.json').read_text(encoding='utf-8'), self.original)

    def test_valid_save_round_trips_temperature_and_mode_tag(self):
        data = week(period(temperature=22.5, temperature_target='room'))
        _, state = self.ns['schedule_write']('ch', json.dumps(data))
        self.assertEqual(state, 'success')
        saved = self.ns['_load_schedule']('ch')
        self.assertEqual(saved[0]['periods'][0]['temperature'], 22.5)
        self.assertEqual(saved[0]['periods'][0]['temperature_target'], 'room')

    def test_load_preserves_incompatible_setpoint_for_editing_but_does_not_apply_it(self):
        data = week(period(temperature=40, temperature_target='water'))
        Path('schedule_ch.json').write_text(json.dumps(data), encoding='utf-8')
        saved = self.ns['_load_schedule']('ch')
        self.assertIsNotNone(saved)
        self.assertEqual(saved[0]['periods'][0]['temperature'], 40)
        self.assertIsNone(logic.period_temperature(saved[0]['periods'][0], 'ch', self.ns['_scheduler_config']()))

    def test_missing_or_corrupt_file_reports_unavailable_not_empty_week(self):
        self.assertIsNone(self.ns['_load_schedule']('dhw'))
        Path('schedule_ch.json').write_text('{broken json', encoding='utf-8')
        self.assertIsNone(self.ns['_load_schedule']('ch'))

    def test_invalid_read_structure_is_not_treated_as_empty_schedule(self):
        data = week(period())
        data[0]['periods'][0]['end'] = 'yesterday'
        Path('schedule_ch.json').write_text(json.dumps(data), encoding='utf-8')
        self.assertIsNone(self.ns['_load_schedule']('ch'))

    def test_atomic_replace_failure_does_not_truncate_previous_file(self):
        new = json.dumps(week(period(temperature=22, temperature_target='room')))
        with patch.object(os, 'replace', side_effect=OSError('simulated disk failure')):
            _, state = self.ns['schedule_write']('ch', new)
        self.assertNotEqual(state, 'success')
        self.assertEqual(Path('schedule_ch.json').read_text(encoding='utf-8'), self.original)


if __name__ == '__main__':
    unittest.main()
