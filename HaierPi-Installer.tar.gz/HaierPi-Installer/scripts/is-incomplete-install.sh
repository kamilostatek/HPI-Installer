#!/usr/bin/env bash
# Konserwatywne wykrywanie przerwanej instalacji pip przed zapisaniem
# konfiguracji i utworzeniem uslugi; nie nadpisuj istniejacego HaierPi.
set -Eeuo pipefail
app="${HAIERPI_APP_DIR:-/opt/haier}"
config="${HAIERPI_CONFIG_FILE:-/opt/config.ini}"
service="${HAIERPI_SERVICE_FILE:-/etc/systemd/system/haier.service}"
[[ -f "$app/main.py" && -f "$app/env/pyvenv.cfg" && ! -e "$config" && ! -e "$service" ]]
