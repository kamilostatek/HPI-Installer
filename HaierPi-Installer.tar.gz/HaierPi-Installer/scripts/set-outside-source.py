#!/usr/bin/env python3
"""Set outside temperature priority in existing HaierPi config without touching HA secrets.

Run only when HaierPi is stopped. Does not enable/disable device-tree overlays.
"""
import argparse
import configparser
from datetime import datetime, timezone
import os
from pathlib import Path
import shutil
import tempfile

SOURCES = {'ha': 'ha', 'ds18b20': 'builtin'}

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('source', choices=tuple(SOURCES))
    ap.add_argument('--config', type=Path, default=Path('/opt/config.ini'))
    args = ap.parse_args()
    if not args.config.is_file():
        ap.error(f'Missing config file: {args.config}')
    p = configparser.ConfigParser(interpolation=None)
    p.read(args.config, encoding='utf-8')
    if not p.has_section('SETTINGS'):
        ap.error(f'No [SETTINGS] section in {args.config}')
    old = p.get('SETTINGS', 'outsidetemp', fallback='<unset>')
    new = SOURCES[args.source]
    if old == new:
        print(f'Źródło temperatury już ustawione na {new}; bez zmian.')
        return
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    backup = args.config.with_name(args.config.name + '.bak-outtemp-' + stamp)
    if backup.exists():
        ap.error(f'Backup name exists: {backup}')
    shutil.copy2(args.config, backup)
    p.set('SETTINGS', 'outsidetemp', new)
    fd, tmp = tempfile.mkstemp(prefix='.config.ini.', dir=args.config.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            p.write(f)
            f.flush()
            os.fsync(f.fileno())
        st = args.config.stat()
        os.chmod(tmp, st.st_mode & 0o777)
        os.chown(tmp, st.st_uid, st.st_gid)
        os.replace(tmp, args.config)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)
    print(f'Źródło temperatury: {old} -> {new}. Kopia konfiguracji: {backup}')
    if args.source == 'ha':
        print('Przed uruchomieniem HaierPi ustaw [HOMEASSISTANT]: HAADDR, HAPORT, KEY i outsidesensor.')
    else:
        print('Włącz nakładkę 1-Wire dla płytki i sprawdź DS18B20 po restarcie.')
    print('Usługa HaierPi nie została uruchomiona.')

if __name__ == '__main__':
    main()
