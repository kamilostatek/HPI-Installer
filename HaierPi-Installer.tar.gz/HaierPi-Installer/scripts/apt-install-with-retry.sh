#!/usr/bin/env bash
# Instaluje pakiety i tylko w razie bledow 404 mirroru Raspbiana
# naprawia adres repozytorium i ponawia probę JEDEN raz.
set -Eeuo pipefail
[[ $EUID -eq 0 ]] || { echo 'Wymagany administrator root.' >&2; exit 1; }
ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
LOG="${HAIERPI_DZIENNIK:-/var/log/haierpi-installer.log}"
APT_GET="${HAIERPI_APT_GET:-apt-get}"
umask 077
mkdir -p "$(dirname -- "$LOG")"
report=$(mktemp)
trap 'rm -f "$report"' EXIT
if "$APT_GET" install -y --no-install-recommends "$@" > "$report" 2>&1; then
  cat "$report" >> "$LOG"
  exit 0
fi
cat "$report" >> "$LOG"
# Zawężenie: nie zmieniaj APT dla błędów innych niż HTTP 404.
if ! grep -Eiq '(404[[:space:]]+Not[[:space:]]+Found|Failed to fetch.*404|Błąd:.*404|Err:.*404)' "$report"; then
  echo '[APT] Instalacja pakietów nie powiodła się; błąd nie dotyczy HTTP 404.' >&2
  exit 1
fi
printf '[APT] Wykryto 404 przy pobieraniu pakietów; sprawdzam archiwum Raspbiana Bullseye...\n' | tee -a "$LOG"
if ! bash "$ROOT_DIR/scripts/repair-raspbian-apt.sh" >> "$LOG" 2>&1; then
  echo "[APT] Nie udało się automatycznie naprawić źródeł Raspbiana. Szczegóły: $LOG" >&2
  exit 1
fi
echo '[APT] Ponawiam pobieranie pakietów po zmianie repozytorium...' | tee -a "$LOG"
if "$APT_GET" install -y --no-install-recommends "$@" >> "$LOG" 2>&1; then
  echo '[APT] Ponowiona instalacja pakietów zakończona pomyślnie.' | tee -a "$LOG"
else
  echo "[APT] Druga próba instalacji nie powiodła się. Szczegóły: $LOG" >&2
  exit 1
fi
