#!/usr/bin/env bash
# Prepare boot configuration for the selected board, do not reboot or start HaierPi.
set -Eeuo pipefail
BOARD="${1:-}"
[[ "$(id -u)" == 0 ]] || { echo 'Uruchom jako administrator (root)' >&2; exit 1; }
[[ "$BOARD" == nanopi || "$BOARD" == rpi ]] || { echo 'Użycie: bash scripts/configure-uart.sh nanopi|rpi' >&2; exit 1; }
backup() { cp -p "$1" "$1.bak-haierpi-$(date -u +%Y%m%dT%H%M%SZ)"; }
if [[ "$BOARD" == nanopi ]]; then
    # Katalog testowy jest opcjonalny; domyślnie modyfikowany jest /boot.
    BOOT_DIR="${HAIERPI_BOOT_DIR:-/boot}"
    BOOT_ENV=''
    for p in "$BOOT_DIR/dietpiEnv.txt" "$BOOT_DIR/armbianEnv.txt"; do
        if [[ -f "$p" ]]; then BOOT_ENV="$p"; break; fi
    done
    [[ -n "$BOOT_ENV" ]] || { echo 'Nie znaleziono konfiguracji rozruchu DietPi/Armbian.' >&2; exit 1; }
    PREFIX="$(sed -n 's/^[[:space:]]*overlay_prefix=//p' "$BOOT_ENV" | tail -n 1 | tr -d '\r')"
    [[ "$PREFIX" =~ ^[A-Za-z0-9._-]+$ ]] || { echo 'Brak poprawnego overlay_prefix w konfiguracji rozruchu.' >&2; exit 1; }
    # DietPi stosuje m.in. /boot/dtb-<kernel>/overlay, nie tylko /boot/dtb.
    UART_FILE="$(find "$BOOT_DIR" -type f -name "${PREFIX}-uart1.dtbo" -print -quit 2>/dev/null)"
    [[ -n "$UART_FILE" ]] || {
        echo "Nie znaleziono nakładki ${PREFIX}-uart1.dtbo w $BOOT_DIR. Nic nie zmieniono." >&2
        exit 1
    }
    if python3 - "$BOOT_ENV" <<'PY_CHECK'
from pathlib import Path
import sys
lines = [l.strip() for l in Path(sys.argv[1]).read_text().splitlines() if l.strip().startswith('overlays=')]
if len(lines) > 1:
    sys.exit(2)
if lines and 'uart1' in lines[0].partition('=')[2].split():
    sys.exit(0)
sys.exit(1)
PY_CHECK
    then
        echo "UART1 jest już wpisany w $BOOT_ENV. Nakładka: $UART_FILE"
    else
        # Błędne powielone wpisy mają przerwać operację, bez zmiany pliku.
        python3 - "$BOOT_ENV" <<'PY_VERIFY'
from pathlib import Path
import sys
lines = [l for l in Path(sys.argv[1]).read_text().splitlines() if l.strip().startswith('overlays=')]
if len(lines) > 1:
    sys.exit('BŁĄD: w pliku jest kilka aktywnych wpisów overlays=. Popraw je ręcznie.')
PY_VERIFY
        backup "$BOOT_ENV"
        python3 - "$BOOT_ENV" <<'PY_WRITE'
from pathlib import Path
import sys
p=Path(sys.argv[1]); lines=p.read_text().splitlines(keepends=True)
found=False
for i,line in enumerate(lines):
    if line.strip().startswith('overlays='):
        name,sep,value=line.partition('=')
        parts=value.strip().split()
        if 'uart1' not in parts:
            parts.append('uart1')
        lines[i]=name+sep+' '.join(parts)+'\n'
        found=True
        break
if not found: lines.append('overlays=uart1\n')
p.write_text(''.join(lines))
PY_WRITE
        echo "Dodano uart1 do $BOOT_ENV. Nakładka: $UART_FILE"
    fi
    echo 'Po restarcie sprawdź komunikację Modbus przez /dev/ttyS1.'

else
    RPI_BOOT_DIR="${HAIERPI_BOOT_DIR:-/boot}"
    CFG=''
    for p in "$RPI_BOOT_DIR/firmware/config.txt" "$RPI_BOOT_DIR/config.txt"; do
        if [[ -f "$p" ]]; then CFG="$p"; break; fi
    done
    [[ -n "$CFG" ]] || { echo 'Nie znaleziono pliku konfiguracji rozruchowej Raspberry Pi.' >&2; exit 1; }
    backup "$CFG"
    python3 - "$CFG" <<'PY'
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
text = p.read_text()
# Do not add conflicting 1-Wire overlays on an alternative GPIO.
active = [line.split('=', 1)[1].split('#', 1)[0].strip()
          for line in text.splitlines()
          if re.match(r'^\s*dtoverlay\s*=', line)]
onewire = [value for value in active if value.split(',')[0].strip() == 'w1-gpio']
for value in onewire:
    match = re.search(r'(?:^|,)\s*gpiopin\s*=\s*([^,\s]+)', value)
    if match and match.group(1) != '4':
        sys.exit('BŁĄD: istniejący overlay w1-gpio używa innego pinu niż GPIO4. Bez zmian w config.txt.')
with p.open('a') as f:
    if not text.endswith('\n'): f.write('\n')
    # [all] is important when config.txt has board-specific sections.
    if '# HaierPi: UART0 for Modbus, Bluetooth disabled' not in text:
        f.write('\n# HaierPi: UART0 for Modbus, Bluetooth disabled\n[all]\nenable_uart=1\ndtoverlay=disable-bt\n')
    if not onewire:
        f.write('\n# HaierPi: DS18B20 1-Wire, GPIO4 (physical pin 7)\n[all]\ndtoverlay=w1-gpio,gpiopin=4\n')
PY
    # Avoid changing host system services when testing against an alternate boot tree.
    if [[ "$RPI_BOOT_DIR" == /boot ]]; then
        for unit in hciuart.service serial-getty@ttyAMA0.service serial-getty@serial0.service; do
            systemctl disable --now "$unit" 2>/dev/null || true
        done
    fi
    for p in "$RPI_BOOT_DIR/firmware/cmdline.txt" "$RPI_BOOT_DIR/cmdline.txt"; do
        if [[ -f "$p" ]]; then
            backup "$p"
            python3 - "$p" <<'PY'
from pathlib import Path
import re,sys
p=Path(sys.argv[1]); text=p.read_text().strip()
text=re.sub(r'(?<!\S)console=(?:serial0|ttyAMA0|ttyS0),\S+\s*', '', text)
p.write_text(' '.join(text.split())+'\n')
PY
            break
        fi
    done
    echo "Skonfigurowano UART0/BT oraz DS18B20 1-Wire GPIO4 w $CFG. Wymagany restart."
fi
