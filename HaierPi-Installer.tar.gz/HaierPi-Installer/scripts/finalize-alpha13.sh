#!/usr/bin/env bash
# Przywroc dokladnie PyHaier z dolaczonej paczki HaierPi 1.4.5 Alpha13
# po zakonczeniu instalacji zaleznosci pip (takze w trybie naprawy).
# Binarki DHT22 dostarczone z paczka: nadaj +x plikom, gdy istnieja.
set -Eeuo pipefail
ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
APP_DIR="${1:-/opt/haier}"
PYTHON="$APP_DIR/env/bin/python"
SOURCE="$ROOT_DIR/app/PyHaier"
[[ -f "$SOURCE/__init__.py" ]] || { echo 'BŁĄD: brak PyHaier w paczce Alpha13.' >&2; exit 1; }
[[ -x "$PYTHON" ]] || { echo 'BŁĄD: brak Pythona w venv HaierPi.' >&2; exit 1; }
[[ -d "$APP_DIR" ]] || { echo 'BŁĄD: brak katalogu aplikacji.' >&2; exit 1; }
SITE_PACKAGES="$("$PYTHON" -c 'import sysconfig; print(sysconfig.get_path("purelib"))')"
case "$SITE_PACKAGES" in
    "$APP_DIR"/env/*/site-packages) ;;
    *) echo 'BŁĄD: nieprawidłowa ścieżka site-packages. Nie kopiuję PyHaier.' >&2; exit 1 ;;
esac
[[ -d "$SITE_PACKAGES" ]] || { echo 'BŁĄD: nie istnieje site-packages venv.' >&2; exit 1; }

zamien_biblioteke() {
    local cel="$1" folder temp poprzednia
    folder="$(dirname -- "$cel")"
    temp="$(mktemp -d "$folder/.PyHaier-alpha13-new.XXXXXXXX")"
    poprzednia="$folder/.PyHaier-alpha13-old.$$"
    cp -a -- "$SOURCE/." "$temp/"
    # Normalizuj uprawnienia biblioteki skopiowanej z archiwum.
    find "$temp" -type d -exec chmod 755 {} +
    find "$temp" -type f -exec chmod 644 {} +
    if [[ -e "$cel" || -L "$cel" ]]; then mv -- "$cel" "$poprzednia"; fi
    if mv -- "$temp" "$cel"; then
        if [[ -e "$poprzednia" || -L "$poprzednia" ]]; then rm -rf -- "$poprzednia"; fi
    else
        [[ -e "$poprzednia" || -L "$poprzednia" ]] && mv -- "$poprzednia" "$cel"
        echo 'BŁĄD: nie udało się podmienić PyHaier.' >&2
        return 1
    fi
}

# Najpierw biblioteka w venv, potem lokalna (lokalna ma pierwszeństwo przy python main.py).
zamien_biblioteke "$SITE_PACKAGES/PyHaier"
zamien_biblioteke "$APP_DIR/PyHaier"
echo 'PyHaier: wersja z paczki 1.4.5 Alpha13 przywrócona po pip (venv i aplikacja).'

if [[ -d "$APP_DIR/bin" ]]; then
    for nazwa in dht22n dht22r dht22s; do
        plik="$APP_DIR/bin/$nazwa"
        if [[ -f "$plik" && ! -L "$plik" ]]; then
            chmod 755 "$plik"
            echo "DHT22: ustawiono uprawnienia wykonywania dla $nazwa."
        else
            echo "DHT22: brak $nazwa w /opt/haier/bin; pominięto chmod (sprawdź kompletność paczki instalatora)."
        fi
    done
else
    echo 'DHT22: brak katalogu bin w paczce Alpha13 — chmod nie jest możliwy. Nie wpływa to na czujnik DS18B20.'
fi
