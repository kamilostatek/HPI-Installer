#!/usr/bin/env bash
# NanoPi NEO: kompatybilnosc starszych statycznych binarek DHT22/WiringNP.
# WiringNP najpierw szuka /sys/class/sunxi_info/sys_info, a potem /etc/sys_info.
# Nie modyfikuj istniejacego /etc/sys_info i nie uruchamiaj tej operacji na RPi.
set -Eeuo pipefail

blad() { printf 'BŁĄD: %s\n' "$*" >&2; exit 1; }
[[ $EUID -eq 0 ]] || blad 'Uruchom jako root.'
MODEL_FILE="${HAIERPI_NANOPI_MODEL_PATH:-/proc/device-tree/model}"
SYSINFO="${HAIERPI_NANOPI_SYSINFO_PATH:-/etc/sys_info}"
[[ -r "$MODEL_FILE" ]] || blad 'Nie można rozpoznać NanoPi NEO z Device Tree.'
MODEL="$(tr -d '\000' < "$MODEL_FILE")"
MODEL_LOWER="${MODEL,,}"
case "$MODEL_LOWER" in
  *'nanopi neo2'*|*'nanopi neo3'*) blad "Nieobsługiwana płytka: $MODEL" ;;
  *'nanopi neo'*) ;;
  *) blad "To nie jest NanoPi NEO: $MODEL" ;;
esac

if [[ -L "$SYSINFO" ]]; then
  blad "$SYSINFO jest dowiązaniem symbolicznym. Plik nie zostanie zmieniony."
fi
if [[ -e "$SYSINFO" ]]; then
  [[ -f "$SYSINFO" ]] || blad "$SYSINFO istnieje, ale nie jest zwykłym plikiem."
  printf 'NanoPi NEO: %s już istnieje — zachowuję bez zmian.\n' "$SYSINFO"
  exit 0
fi

# Pola zgodne ze wzorcem potwierdzonym przez użytkownika NanoPi NEO.
# sunxi_chipid to przykładowa wartość z referencyjnego obrazu; nie służy
# do weryfikacji unikalnej tożsamości układu.
TMP="$(mktemp "${SYSINFO}.haierpi.XXXXXXXX")" || blad 'Nie można przygotować pliku tymczasowego.'
trap 'rm -f -- "$TMP"' EXIT
cat > "$TMP" <<'EOF'
sunxi_platform    : Allwinnersun8iFamily
sunxi_secure      : normal
sunxi_chipid      : 2c21020e786746240000540000000000
sunxi_chiptype    : 00000042
sunxi_batchno     : 1
sunxi_board_id    : 1(0)
EOF
chmod 644 "$TMP"
# Dowiązanie twarde chroni przed przypadkowym nadpisaniem pliku utworzonego
# w międzyczasie przez inny proces.
if ! ln -- "$TMP" "$SYSINFO" 2>/dev/null; then
  blad "Nie udało się bezpiecznie utworzyć $SYSINFO (być może plik już istnieje)."
fi
printf 'NanoPi NEO: utworzono %s dla zgodności DHT22/WiringNP.\n' "$SYSINFO"
