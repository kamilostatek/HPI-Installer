#!/usr/bin/env bash
# Instalator DietPi. Usluga nie jest uruchamiana przed restartem.
set -Eeuo pipefail
IFS=$'\n\t'
ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
BOARD="${1:-}"
APP_DIR=/opt/haier

# Standardowe narzedzia APT i pip wypisuja komunikaty we wlasnym jezyku.
# Instalator pokazuje polskie podsumowanie; szczegoly sa w pliku dziennika.
DZIENNIK="${HAIERPI_DZIENNIK:-/var/log/haierpi-installer.log}"
umask 077
mkdir -p "$(dirname -- "$DZIENNIK")"
touch "$DZIENNIK"
wykonaj_z_logiem() {
  local opis="$1"
  shift
  log "$opis - trwa..."
  if "$@" >> "$DZIENNIK" 2>&1; then
    log "$opis - zakończono pomyślnie."
  else
    fail "$opis nie powiodło się. Szczegóły: $DZIENNIK"
  fi
}

fail() { printf 'BŁĄD: %s\n' "$*" >&2; exit 1; }
log() { printf '\n[Instalator HaierPi] %s\n' "$*"; }

[[ $EUID -eq 0 ]] || fail 'Uruchom jako root: sudo bash install.sh nanopi LUB sudo bash install.sh rpi'
[[ "$BOARD" == nanopi || "$BOARD" == rpi ]] || fail 'Wybierz płytkę: nanopi lub rpi'
[[ -f "$ROOT_DIR/app/main.py" && -f "$ROOT_DIR/requirements-pinned.txt" ]] || fail 'Niekompletna paczka instalacyjna'
# Kontrola kompletności przed instalacją pakietów: plik README harmonogramu nie jest wymagany.
for element in static templates HPi PyHaier tests; do
  [[ -d "$ROOT_DIR/app/$element" ]] || fail "Brakuje katalogu aplikacji: $element. Przerwano przed instalacją zależności."
done
[[ -f /etc/os-release ]] || fail 'Nie znaleziono systemu Debian/DietPi'
# shellcheck disable=SC1091
source /etc/os-release
[[ "${ID:-}" == debian || " ${ID_LIKE:-} " == *' debian '* ]] || fail 'Obsługiwane są tylko Debian i DietPi'
[[ "$BOARD" == nanopi ]] && model='NanoPi NEO' || model='Raspberry Pi Zero / Zero 2'
log "Wybrany profil sprzętowy: $model"

# NanoPi NEO chooses between a physical DS18B20 and Home Assistant.
# Raspberry Pi Zero W / Zero 2 W uses the physical DS18B20 on GPIO4.
if [[ "$BOARD" == nanopi ]]; then
  OUTSIDE_SOURCE="${HAIERPI_OUTSIDE_SOURCE:-}"
  if [[ -z "$OUTSIDE_SOURCE" ]]; then
    [[ -r /dev/tty ]] || fail 'Wymagany terminal interaktywny. W trybie automatycznym ustaw HAIERPI_OUTSIDE_SOURCE=ha albo ds18b20.'
    printf '\nSkąd NanoPi NEO ma odczytywać temperaturę zewnętrzną?\n' > /dev/tty
    printf '  1) Fizyczny czujnik DS18B20 (1-Wire, PA6)\n' > /dev/tty
    printf '  2) Home Assistant (encja temperatury)\n' > /dev/tty
    while true; do
      read -r -p 'Wybór [1/2]: ' answer < /dev/tty || fail 'Nie podano odpowiedzi.'
      case "$answer" in
        1) OUTSIDE_SOURCE=ds18b20; break ;;
        2) OUTSIDE_SOURCE=ha; break ;;
        *) printf 'Wpisz 1 albo 2.\n' > /dev/tty ;;
      esac
    done
  fi
  [[ "$OUTSIDE_SOURCE" == ha || "$OUTSIDE_SOURCE" == ds18b20 ]] || fail 'Zmienna HAIERPI_OUTSIDE_SOURCE musi mieć wartość ha lub ds18b20.'
  log "NanoPi: źródło temperatury zewnętrznej: $OUTSIDE_SOURCE"
else
  [[ -z "${HAIERPI_OUTSIDE_SOURCE:-}" || "${HAIERPI_OUTSIDE_SOURCE:-}" == ds18b20 ]] || \
    fail 'Raspberry Pi w tym profilu korzysta z fizycznego DS18B20 (GPIO4).'
  OUTSIDE_SOURCE=ds18b20
  log 'Raspberry Pi: fizyczny DS18B20, GPIO4, źródło builtin.'
fi
ROOT_FS="$(findmnt -n -o FSTYPE / || true)"
ROOT_OPTS="$(findmnt -n -o OPTIONS / || true)"
[[ "$ROOT_FS" != overlay ]] || fail 'System główny korzysta z nakładki RAM; zapisane zmiany mogą zniknąć po restarcie'
[[ ",$ROOT_OPTS," == *,rw,* ]] || fail 'System plików jest tylko do odczytu'
if [[ -f /opt/haier/main.py ]]; then
  fail 'HaierPi jest już zainstalowany. W menu wybierz opcję 5 przed czystą instalacją.'
fi
FREE_KB="$(df -Pk /opt | awk 'NR==2 {print $4}')"
[[ "$FREE_KB" =~ ^[0-9]+$ ]] || fail 'Nie można sprawdzić wolnego miejsca w /opt'
(( FREE_KB >= 800000 )) || fail 'Wymagane jest przynajmniej 800 MB wolnego miejsca w /opt. Powiększ partycję karty microSD.'

log 'Sprawdzam repozytoria APT; archiwum Bullseye zostanie użyte tylko w razie potrzeby'
export DEBIAN_FRONTEND=noninteractive
bash "$ROOT_DIR/scripts/repair-bullseye-apt.sh"
log 'Instaluję Pythona i pakiety systemowe przez APT'
wykonaj_z_logiem 'Odświeżenie listy pakietów' apt-get update
wykonaj_z_logiem 'Instalacja pakietów systemowych' apt-get install -y --no-install-recommends python3 python3-venv python3-pip python3-dev build-essential curl git ca-certificates p7zip-full pkg-config libssl-dev libffi-dev liblzma-dev zlib1g-dev libbz2-dev libreadline-dev libsqlite3-dev
PY_VERSION="$(python3 -c 'import sys; print(sys.version_info.major * 100 + sys.version_info.minor)')"
if (( PY_VERSION < 309 || PY_VERSION > 311 )); then
  fail 'Zestaw zależności Alpha13 wymaga Pythona 3.9-3.11; wykryta wersja nie była testowana.'
fi
log 'Kopiuję pliki HaierPi i tworzę odrębne środowisko Python'
install -d -m 755 "$APP_DIR"
cp -a "$ROOT_DIR/app/main.py" "$ROOT_DIR/app/static" "$ROOT_DIR/app/templates" "$ROOT_DIR/app/HPi" "$ROOT_DIR/app/PyHaier" "$ROOT_DIR/app/tests" "$APP_DIR/"
# W niektorych wydaniach HaierPi binarki czujnikow dostarczane sa w app/bin.
# Skopiuj je, gdy sa dostepne; uprawnienia nada osobny etap finalize-alpha13.sh.
if [[ -d "$ROOT_DIR/app/bin" ]]; then
  cp -a "$ROOT_DIR/app/bin" "$APP_DIR/"
fi
# Na RPi przechodzimy z numerow BCM na globalne identyfikatory sysfs.
# NanoPi zachowuje dotychczasowy HPi/GPIO.py bez zmian.
if [[ "$BOARD" == rpi ]]; then
  bash "$ROOT_DIR/scripts/apply-gpio-rpi.sh" "$APP_DIR/HPi/GPIO.py"
fi
python3 -m venv "$APP_DIR/env"
# Some DietPi images mount /tmp in RAM; use disk-backed /var/tmp for pip builds.
export TMPDIR=/var/tmp PIP_NO_CACHE_DIR=1
wykonaj_z_logiem 'Instalacja bibliotek Python (pip)' "$APP_DIR/env/bin/python" -m pip install --disable-pip-version-check -r "$ROOT_DIR/requirements-pinned.txt"
# Ostatni etap instalacji bibliotek: wymusz oryginalną PyHaier z 1.4.5 Alpha13.
wykonaj_z_logiem 'Przywracanie PyHaier Alpha13 i uprawnien DHT22' bash "$ROOT_DIR/scripts/finalize-alpha13.sh" "$APP_DIR"

log 'Sprawdzam dostępność bibliotek Python'
(cd "$APP_DIR" && "$APP_DIR/env/bin/python" - <<'PY'
import flask, werkzeug, flask_babel, flask_socketio
import jinja2, requests, serial, socketio, PyHaier
import paho.mqtt.client, schedule, termcolor, waitress
import w1thermsensor, HPi.GPIO
from pymodbus.client.sync import ModbusSerialClient
from flask_simplelogin import SimpleLogin
from flask import Markup
print('Test bibliotek Pythona: poprawny')
PY
)
log 'Przygotowuję konfigurację i konto administratora HaierPi'
"$APP_DIR/env/bin/python" "$ROOT_DIR/scripts/configure.py" "$BOARD" "$OUTSIDE_SOURCE"
# Aktualizuj źródło także w zachowanym config.ini; dotyczy obu platform.
python3 "$ROOT_DIR/scripts/set-outside-source.py" "$OUTSIDE_SOURCE"
log 'Sprawdzam ModbusDev i GPIO dla wybranej plytki'
python3 "$ROOT_DIR/scripts/apply-board-profile.py" "$BOARD" || fail 'Nie udalo sie dopasowac GPIO i ModbusDev. Usługa pozostaje wyłączona.'
install -m 644 "$ROOT_DIR/systemd/haier.service" /etc/systemd/system/haier.service
systemctl daemon-reload
install -m 755 "$ROOT_DIR/enable-haierpi.sh" /usr/local/sbin/haierpi-wlacz
systemctl disable --now haier.service 2>/dev/null || true
UART_POPRAWNY=0
if [[ "${HAIERPI_AUTO_UART:-1}" == 1 ]]; then
  log 'Przygotowuję ustawienia UART (bez restartu)'
  if bash "$ROOT_DIR/scripts/configure-uart.sh" "$BOARD"; then
    UART_POPRAWNY=1
    log 'Zmieniono ustawienia UART. Przed uruchomieniem HaierPi wykonaj restart urządzenia.'
  else
    log 'UWAGA: nie udało się skonfigurować UART. Wykonaj kroki z README_PL.md.'
  fi
else
  log 'HAIERPI_AUTO_UART=0: pozostawiono ustawienia UART bez zmian.'
fi
if [[ "$BOARD" == nanopi ]]; then
  if [[ "$OUTSIDE_SOURCE" == ds18b20 ]]; then
    log 'NanoPi NEO: włączam 1-Wire PA6 dla DS18B20 (wymagany restart)'
    bash "$ROOT_DIR/scripts/configure-onewire-nanopi.sh" || \
      fail 'Nie udało się włączyć nakładki DS18B20. Usługa pozostaje wyłączona.'
  else
    log 'NanoPi NEO: wybrano Home Assistant; bez zmian 1-Wire.'
    log 'Przed startem HaierPi uzupełnij [HOMEASSISTANT] HAADDR/HAPORT/KEY/outsidesensor w /opt/config.ini.'
  fi
else
  log 'Raspberry Pi: 1-Wire GPIO4 skonfigurowany wraz z UART w config.txt (wymagany restart).'
fi
# Diagnostyka jest dostarczona w paczce (na podstawie pliku uzytkownika).
# NIE uruchamiamy jej podczas instalacji; testy wymagaja recznego potwierdzenia.
install -d -m 700 "$APP_DIR/tools"
install -m 600 "$ROOT_DIR/diagnostics/diagnostics.py" "$APP_DIR/tools/diagnostics.py"
install -m 600 "$ROOT_DIR/diagnostics/diagnostic-original.py" "$APP_DIR/tools/diagnostic-original.py"
install -m 755 "$ROOT_DIR/scripts/diagnostics-haierpi.sh" /usr/local/sbin/haierpi-diagnostyka
log 'Diagnostyka offline: sudo haierpi-diagnostyka (testy nie uruchamiaja sie automatycznie).'

log 'Instalacja zakończona. HaierPi nie został jeszcze uruchomiony.'

printf 'Wpisy ModbusDev i GPIO sprawdzono dla wybranej płytki.\n'
printf 'Przed uruchomieniem sterowania sprawdź fizyczne połączenia oraz działanie UART.\n'
if [[ "$UART_POPRAWNY" == 1 ]]; then
  bash "$ROOT_DIR/scripts/autostart.sh"
else
  log 'UWAGA: konfiguracja UART nie została potwierdzona. Ze względów bezpieczeństwa autostart pozostaje wyłączony.'
  printf 'Najpierw popraw UART w opcji 2 menu.\n'
fi

# Pytanie pojawia się dopiero po pomyślnie zakończonej pełnej instalacji.
# Domyślna odpowiedź N zapobiega nieoczekiwanemu przerwaniu połączenia SSH.
if [[ -r /dev/tty ]]; then
  printf '\nW celu zastosowania zmian UART i 1-Wire wymagany jest restart DietPi.\n' > /dev/tty
  while true; do
    read -r -p 'Czy chcesz teraz ponownie uruchomić DietPi? [T/N]: ' ODPOWIEDZ < /dev/tty || ODPOWIEDZ='N'
    case "${ODPOWIEDZ^^}" in
      T)
        printf 'Ponowne uruchamianie DietPi. Połączenie SSH zostanie przerwane.\n' > /dev/tty
        if ! systemctl reboot; then
          printf 'BŁĄD: nie udało się uruchomić restartu. Wykonaj ręcznie: reboot\n' >&2
          exit 1
        fi
        break
        ;;
      N|'')
        printf 'Pominięto restart. Aby zastosować zmiany, wykonaj później: reboot\n' > /dev/tty
        break
        ;;
      *)
        printf 'Wpisz T (tak) albo N (nie).\n' > /dev/tty
        ;;
    esac
  done
else
  printf 'Nie wykryto terminala. Restart pominięty; wykonaj później: reboot\n'
fi
