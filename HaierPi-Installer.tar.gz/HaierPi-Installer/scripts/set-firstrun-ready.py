#!/usr/bin/env python3
"""Unlock HaierPi UI after successful installer hardware configuration.

Preserves all unrelated configuration lines. Does not start the service.
"""
import argparse
import configparser
from datetime import datetime, timezone
import os
from pathlib import Path
import re
import shutil
import tempfile

SECTION = re.compile(r'^\s*\[([^]]+)\]\s*(?:[;#].*)?$')
ENTRY = re.compile(r'^(\s*firstrun\s*[=:]\s*)([^\s;#]+)(\s*(?:[;#].*)?)(\r?\n)?$', re.IGNORECASE)


def patch(contents):
    config = configparser.ConfigParser(interpolation=None, inline_comment_prefixes=('#', ';'))
    config.read_string(contents)
    if not config.has_section('MAIN'):
        raise ValueError('Brakuje sekcji [MAIN].')
    old = config.get('MAIN', 'firstrun', fallback=None)
    if old not in ('0', '1', None):
        raise ValueError('Nieoczekiwana wartość firstrun: ' + repr(old))
    if old == '0':
        return contents, False
    lines = contents.splitlines(keepends=True)
    output = []
    in_main = False
    found = False
    inserted = False
    for line in lines:
        section = SECTION.match(line.rstrip('\r\n'))
        if section:
            if in_main and not found:
                if output and not output[-1].endswith('\n'):
                    output[-1] += '\n'
                output.append('firstrun = 0\n')
                inserted = True
            in_main = section.group(1).lower() == 'main'
            output.append(line)
            continue
        if in_main:
            entry = ENTRY.match(line)
            if entry:
                if found:
                    raise ValueError('Wiele wpisów firstrun w sekcji [MAIN].')
                if entry.group(2) != '1':
                    raise ValueError('Nieoczekiwana wartość firstrun.')
                line = entry.group(1) + '0' + entry.group(3) + (entry.group(4) or '')
                found = True
        output.append(line)
    if in_main and not found:
        if output and not output[-1].endswith('\n'):
            output[-1] += '\n'
        output.append('firstrun = 0\n')
        inserted = True
    if not (found or inserted):
        raise ValueError('Nie udało się odnaleźć sekcji [MAIN].')
    result = ''.join(output)
    check = configparser.ConfigParser(interpolation=None, inline_comment_prefixes=('#', ';'))
    check.read_string(result)
    if check.get('MAIN', 'firstrun') != '0':
        raise ValueError('Nie udało się zapisać firstrun = 0.')
    return result, True


def main():
    arg = argparse.ArgumentParser(description='Odblokowuje zakładki HaierPi po konfiguracji sprzętu.')
    arg.add_argument('--config', type=Path, default=Path('/opt/config.ini'))
    args = arg.parse_args()
    path = args.config
    if path.is_symlink() or not path.is_file():
        arg.error('Nie znaleziono bezpiecznego pliku config.ini: ' + str(path))
    try:
        original = path.read_text(encoding='utf-8-sig')
        updated, changed = patch(original)
    except (OSError, UnicodeError, ValueError, configparser.Error) as exc:
        arg.error('Nie udało się odblokować HaierPi: ' + str(exc))
    if not changed:
        print('HaierPi: [MAIN] firstrun = 0 jest już ustawione. Bez zmian.')
        return
    st = path.stat()
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    fd, temp_name = tempfile.mkstemp(prefix='.haierpi-firstrun-', dir=path.parent)
    backup = path.with_name(path.name + '.bak-firstrun-' + stamp)
    try:
        shutil.copy2(path, backup)
        os.chmod(backup, 0o600)
        with os.fdopen(fd, 'w', encoding='utf-8', newline='') as f:
            f.write(updated)
            f.flush()
            os.fsync(f.fileno())
        os.chmod(temp_name, st.st_mode & 0o777)
        os.chown(temp_name, st.st_uid, st.st_gid)
        os.replace(temp_name, path)
        temp_name = None
    finally:
        if temp_name is not None and os.path.exists(temp_name):
            os.unlink(temp_name)
    print('Konfiguracja HaierPi ukończona: [MAIN] firstrun = 0.')
    print('Po uruchomieniu HaierPi wszystkie zakładki będą dostępne.')
    print('Kopia bezpieczeństwa: ' + str(backup))


if __name__ == '__main__':
    main()
