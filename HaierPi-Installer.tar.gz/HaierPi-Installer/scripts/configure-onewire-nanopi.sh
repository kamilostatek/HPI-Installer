#!/usr/bin/env bash
# Optional HaierPi DS18B20 1-Wire support for NanoPi NEO (Allwinner H3).
# Installs the supplied PA6 overlay in overlay-user; never overwrites kernel DTBs.
set -Eeuo pipefail

fail() { printf 'BŁĄD: %s\n' "$*" >&2; exit 1; }
[[ "$(id -u)" == 0 ]] || fail 'Uruchom jako root: sudo bash scripts/configure-onewire-nanopi.sh'

ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
SRC="$ROOT_DIR/overlays/haierpi-w1-pa6.dtbo"
[[ -s "$SRC" ]] || fail "Brak nakładki: $SRC"
[[ -f /proc/device-tree/compatible ]] || fail 'Brak listy zgodności Device Tree.'
tr '\000' '\n' < /proc/device-tree/compatible | grep -Fxq 'allwinner,sun8i-h3' || \
  fail 'Skrypt jest przeznaczony wyłącznie dla Allwinner H3 / NanoPi NEO, nie Raspberry Pi.'

BOOT_ENV=''
for file in /boot/dietpiEnv.txt /boot/armbianEnv.txt; do
  if [[ -f "$file" ]]; then BOOT_ENV="$file"; break; fi
done
[[ -n "$BOOT_ENV" ]] || fail 'Nie znaleziono /boot/dietpiEnv.txt ani /boot/armbianEnv.txt.'

# For this mode, the active U-Boot script must consume user_overlays.
[[ -f /boot/boot.scr ]] || fail 'Brak /boot/boot.scr; nie można potwierdzić obsługi user_overlays.'
LC_ALL=C grep -aq 'user_overlays' /boot/boot.scr || \
  fail 'boot.scr nie zawiera user_overlays. Nic nie zmieniono; sprawdź ustawienia rozruchowe.'

# Prevent two w1 masters from being activated via both overlay variables.
python3 - "$BOOT_ENV" <<'PY'
from pathlib import Path
import sys
p = Path(sys.argv[1])
lines = p.read_text(encoding='utf-8').splitlines()
for var in ('overlays', 'user_overlays'):
    hits = [x for x in lines if x.strip().startswith(var+'=')]
    if len(hits) > 1:
        sys.exit(f'BŁĄD: powielone wpisy {var}= w {p}; popraw je ręcznie.')
    if var == 'overlays' and hits:
        names = hits[0].split('=',1)[1].split()
        if 'w1-gpio' in names:
            sys.exit(f'BŁĄD: w1-gpio jest już włączone w {p}. Nie można włączać drugiej nakładki.')
PY

# Check the file is a valid DTB overlay for H3 with the expected PA6 pin.
python3 - "$SRC" <<'PY'
from pathlib import Path
import struct, sys
b = Path(sys.argv[1]).read_bytes()
if len(b) < 40:
    sys.exit('BŁĄD: niepoprawny DTBO (zbyt krótki)')
h = struct.unpack_from('>10I', b)
magic,total,os,ots,_,_,_,_,ss,sst = h
if magic != 0xd00dfeed or total != len(b):
    sys.exit('BŁĄD: niepoprawny nagłówek DTBO')
strings = b[ots:ots+ss]
off = os
vals = {}
while off < os+sst:
    tag, = struct.unpack_from('>I', b, off); off += 4
    if tag == 1:
        off = (b.index(b'\0', off)+4)//4*4
    elif tag == 2 or tag == 4:
        continue
    elif tag == 3:
        n, no = struct.unpack_from('>II', b, off); off += 8
        name = strings[no:strings.index(b'\0', no)].decode('ascii')
        val = b[off:off+n]
        vals.setdefault(name, []).append(val)
        off = (off+n+3)//4*4
    elif tag == 9:
        break
    else:
        sys.exit('BŁĄD: nieoczekiwany znacznik DTBO')
if b'allwinner,sun8i-h3\0' not in vals.get('compatible', []):
    sys.exit('BŁĄD: nakładka nie jest przeznaczona dla Allwinner H3')
if b'PA6\0' not in vals.get('pins', []):
    sys.exit('BŁĄD: nakładka nie obsługuje pinu PA6')
if b'w1-gpio\0' not in vals.get('compatible', []):
    sys.exit('BŁĄD: w nakładce brak węzła w1-gpio')
PY

TARGET_DIR=/boot/overlay-user
TARGET="$TARGET_DIR/haierpi-w1-pa6.dtbo"
mkdir -p "$TARGET_DIR"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
if [[ -f "$TARGET" ]] && ! cmp -s "$SRC" "$TARGET"; then
  cp -p "$TARGET" "$TARGET.bak-haierpi-$STAMP"
fi
install -m 644 "$SRC" "$TARGET"
cp -p "$BOOT_ENV" "$BOOT_ENV.bak-haierpi-$STAMP"
python3 - "$BOOT_ENV" <<'PY'
from pathlib import Path
import sys
p = Path(sys.argv[1])
lines = p.read_text(encoding='utf-8').splitlines()
found = False
out=[]
for line in lines:
    if line.strip().startswith('user_overlays='):
        names = line.partition('=')[2].split()
        if 'haierpi-w1-pa6' not in names:
            names.append('haierpi-w1-pa6')
        out.append('user_overlays='+' '.join(names))
        found=True
    else:
        out.append(line)
if not found:
    out.append('user_overlays=haierpi-w1-pa6')
p.write_text('\n'.join(out)+'\n', encoding='utf-8')
PY
sync
printf 'Zainstalowano %s\n' "$TARGET"
printf 'Włączono user_overlays=haierpi-w1-pa6 w %s\n' "$BOOT_ENV"
printf 'Pin 1-Wire: PA6 (Linux GPIO6), pin fizyczny 12 na NanoPi NEO.\n'
printf 'WYMAGANY RESTART. Potem sprawdź: ls /sys/bus/w1/devices/\n'
