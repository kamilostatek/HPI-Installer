"""HaierPi GPIO for Raspberry Pi Zero/Zero 2 (BCM GPIO numbers).

The legacy HaierPi app uses the Linux sysfs GPIO API. Newer kernels may
allocate the Broadcom gpiochip at a non-zero global base, so BCM 17 may be
/sys/class/gpio/gpio529 rather than gpio17. Resolve the mapping explicitly.

No GPIO is exported and no outputs are changed on module import.
"""

import errno
import time
from functools import lru_cache
from pathlib import Path

HIGH, LOW = 1, 0
OUT, IN = 'out', 'in'
BASE = Path('/sys/class/gpio')
_OWNED = set()


@lru_cache(maxsize=1)
def _primary_gpiochip():
    """Locate the on-SoC Broadcom controller; never select an expander."""
    matches = []
    for chip in BASE.glob('gpiochip*'):
        if not chip.is_dir():
            continue
        try:
            label = (chip / 'label').read_text(encoding='ascii').strip().lower()
            base = int((chip / 'base').read_text(encoding='ascii').strip())
            count = int((chip / 'ngpio').read_text(encoding='ascii').strip())
        except (OSError, ValueError):
            continue
        if base < 0 or count < 28:
            continue
        if ('pinctrl-bcm' in label or 'bcm2835-gpio' in label or
                'bcm2711-gpio' in label):
            matches.append((base, count, label))

    if len(matches) != 1:
        raise RuntimeError(
            'Nie mozna jednoznacznie wykryc glownego kontrolera GPIO BCM '
            'Raspberry Pi w /sys/class/gpio/gpiochip*. '
            'Nie zmieniono GPIO, sprawdz jadro i interfejs sysfs.'
        )
    return matches[0]


def _sysfs_pin(pin):
    bcm = int(pin)
    base, count, _ = _primary_gpiochip()
    if bcm < 0 or bcm >= count:
        raise ValueError('GPIO BCM poza zakresem glownego kontrolera: ' + str(bcm))
    return base + bcm


def _gpio_dir(pin):
    return BASE / ('gpio' + str(_sysfs_pin(pin)))


def setup(pin, action):
    if action not in (OUT, IN):
        raise ValueError('GPIO direction must be in or out')
    resolved = _sysfs_pin(pin)
    path = BASE / ('gpio' + str(resolved))
    if not path.is_dir():
        try:
            (BASE / 'export').write_text(str(resolved), encoding='ascii')
            _OWNED.add(resolved)
        except OSError as exc:
            # Another process may have exported the pin in the meantime.
            if exc.errno != errno.EBUSY:
                raise
        for _ in range(50):
            if path.is_dir():
                break
            time.sleep(0.01)
        if not path.is_dir():
            raise RuntimeError('Nie mozna udostepnic GPIO sysfs: ' + str(resolved))
    (path / 'direction').write_text(action, encoding='ascii')


def output(pin, value):
    (_gpio_dir(pin) / 'value').write_text(str(int(value)), encoding='ascii')


def input(pin):
    return (_gpio_dir(pin) / 'value').read_text(encoding='ascii').strip()


def cleanup(pin):
    # Never unexport a line managed by another process.
    resolved = _sysfs_pin(pin)
    if resolved in _OWNED:
        if (BASE / ('gpio' + str(resolved))).is_dir():
            (BASE / 'unexport').write_text(str(resolved), encoding='ascii')
        _OWNED.discard(resolved)
