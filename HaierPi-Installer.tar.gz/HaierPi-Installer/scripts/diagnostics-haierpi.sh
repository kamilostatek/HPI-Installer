#!/usr/bin/env bash
# Lokalna diagnostyka HaierPi z paczki instalacyjnej, bez pobierania ani automatycznego uruchamiania.
set -Eeuo pipefail
KATALOG=/opt/haier/tools
PLIK="$KATALOG/diagnostics.py"
TRYB="${1:---run}"
blad(){ echo "BŁĄD: $*" >&2; exit 1; }
[[ $EUID -eq 0 ]] || blad 'Uruchom: sudo haierpi-diagnostyka'
[[ "$TRYB" == '--run' || "$TRYB" == '--show-path' || "$TRYB" == '--update' || "$TRYB" == '--install' ]] || blad 'Użycie: haierpi-diagnostyka [--run|--show-path|--update|--install]'
[[ -d /opt/haier ]] || blad 'Nie znaleziono /opt/haier.'
[[ ! -L "$KATALOG" && ! -L "$PLIK" ]] || blad 'Niedozwolone dowiązanie symboliczne.'
case "$TRYB" in
  --show-path) [[ -s "$PLIK" ]] || blad 'Brak diagnostyki'; echo "$PLIK"; exit 0 ;;
  --install)
    [[ -s "$PLIK" ]] || blad 'Brak pliku. Diagnostyka jest dołączona do pełnej paczki instalacyjnej.'
    echo "Diagnostyka zainstalowana: $PLIK"; exit 0 ;;
  --update)
    echo 'Aktualizacja skryptu z Internetu nie jest wykonywana automatycznie.'
    echo "Weryfikowana lokalna wersja znajduje się w: $PLIK"
    echo 'Nową wersję instaluj poprzez aktualizację paczki HaierPi Installer.'
    exit 0 ;;
esac
[[ -s "$PLIK" ]] || blad 'Brakuje diagnostyki; zainstaluj HaierPi z kompletnej paczki.'
[[ -x /opt/haier/env/bin/python ]] || blad 'Brak środowiska Python /opt/haier/env.'
[[ -r /dev/tty ]] || blad 'Uruchom w terminalu SSH lub konsoli.'
printf '\n=== Diagnostyka HaierPi ===\n' > /dev/tty
printf 'UWAGA: diagnostyka przełącza przekaźniki GPIO i odczytuje UART RS485.\n' > /dev/tty
printf 'Najpierw upewnij się, że sterowanie pompą może zostać bezpiecznie zatrzymane.\n' > /dev/tty
read -r -p 'Kontynuować diagnostykę? [T/N]: ' ODP < /dev/tty || ODP=N
[[ "${ODP^^}" == T ]] || { echo 'Anulowano.'; exit 0; }
if systemctl is-active --quiet haier.service; then
  printf 'Usługa haier.service działa i musi zostać zatrzymana.\n' > /dev/tty
  read -r -p 'Zatrzymać usługę HaierPi przed diagnostyką? [T/N]: ' ODP < /dev/tty || ODP=N
  [[ "${ODP^^}" == T ]] || blad 'Anulowano; usługa pozostała uruchomiona.'
  systemctl stop haier.service || blad 'Nie udało się zatrzymać usługi.'
  sleep 1
  ! systemctl is-active --quiet haier.service || blad 'Usługa nadal działa. Diagnostyka nie została uruchomiona.'
fi
printf '\nRozpoczynam lokalną diagnostykę. Usługa pozostanie zatrzymana.\n' > /dev/tty
set +e
(cd /opt && PYTHONPATH="/opt/haier${PYTHONPATH:+:$PYTHONPATH}" /opt/haier/env/bin/python "$PLIK") < /dev/tty
STATUS=$?
set -e
printf '\nDiagnostyka zakończona (status %s).\n' "$STATUS" > /dev/tty
printf 'Usługa haier.service nie zostanie uruchomiona bez Twojej zgody.\n' > /dev/tty
read -r -p 'Czy ponownie uruchomić HaierPi? [T/N]: ' ODP < /dev/tty || ODP=N
if [[ "${ODP^^}" == T ]]; then
  systemctl start haier.service || blad 'Nie udało się uruchomić haier.service.'
  echo 'Usługa HaierPi uruchomiona.'
else
  echo 'HaierPi pozostał zatrzymany. Ręczne uruchomienie: systemctl start haier.service'
fi
exit "$STATUS"
