#!/usr/bin/env bash
# Repair or (re)install pinned Python dependencies in a dedicated venv.
set -Eeuo pipefail
ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
DZIENNIK="${HAIERPI_DZIENNIK:-/var/log/haierpi-installer.log}"
umask 077
mkdir -p "$(dirname -- "$DZIENNIK")"
touch "$DZIENNIK"
wykonaj() {
  local opis="$1"; shift
  printf '[Naprawa bibliotek] %s - trwa...\n' "$opis"
  "$@" >> "$DZIENNIK" 2>&1 || { printf 'BŁĄD: %s. Szczegóły: %s\n' "$opis" "$DZIENNIK" >&2; return 1; }
  printf '[Naprawa bibliotek] %s - gotowe.\n' "$opis"
}
[[ $EUID -eq 0 ]] || { echo 'Uruchom jako administrator (root).' >&2; exit 1; }
[[ -d /opt/haier ]] || { echo 'Nie znaleziono katalogu /opt/haier.' >&2; exit 1; }
[[ -f "$ROOT_DIR/requirements-pinned.txt" ]] || { echo 'Nie znaleziono listy wymaganych bibliotek.' >&2; exit 1; }
findmnt -n -o FSTYPE / | grep -Fxq overlay && { echo 'System działa z nakładki RAM; zmiany mogą zniknąć po restarcie.' >&2; exit 1; }
findmnt -n -o OPTIONS / | grep -qE '(^|,)rw(,|$)' || { echo 'System plików jest tylko do odczytu.' >&2; exit 1; }
export DEBIAN_FRONTEND=noninteractive
bash "$ROOT_DIR/scripts/repair-bullseye-apt.sh"
wykonaj 'Odświeżenie pakietów APT' apt-get update
wykonaj 'Pakiety systemowe' apt-get install -y --no-install-recommends python3 python3-venv python3-pip python3-dev build-essential ca-certificates pkg-config libssl-dev libffi-dev liblzma-dev zlib1g-dev libbz2-dev libreadline-dev libsqlite3-dev
PY_VERSION="$(python3 -c 'import sys; print(sys.version_info.major * 100 + sys.version_info.minor)')"
(( PY_VERSION >= 309 && PY_VERSION <= 311 )) || { echo 'Wymagany Python 3.9-3.11 dla sprawdzonych bibliotek.' >&2; exit 1; }
if [[ ! -x /opt/haier/env/bin/python ]]; then
  python3 -m venv /opt/haier/env
fi
export TMPDIR=/var/tmp PIP_NO_CACHE_DIR=1
wykonaj "Ponowna instalacja bibliotek pip" /opt/haier/env/bin/python -m pip install --disable-pip-version-check --upgrade --force-reinstall -r "$ROOT_DIR/requirements-pinned.txt"
wykonaj "Sprawdzenie zgodności bibliotek" /opt/haier/env/bin/python -m pip check
# Takze po naprawie pip ostatnie slowo ma biblioteka z 1.4.5 Alpha13.
wykonaj 'Przywracanie PyHaier Alpha13 i uprawnien DHT22' bash "$ROOT_DIR/scripts/finalize-alpha13.sh" /opt/haier
(cd /opt/haier && /opt/haier/env/bin/python - <<'PY'
import flask, werkzeug, flask_babel, flask_socketio
import jinja2, requests, serial, socketio, PyHaier
import paho.mqtt.client, schedule, termcolor, waitress
import w1thermsensor, HPi.GPIO
from pymodbus.client.sync import ModbusSerialClient
from flask_simplelogin import SimpleLogin
from flask import Markup
print('Wymagane biblioteki Pythona: dostępne')
PY
)
echo 'Zakończono naprawę bibliotek. Usługa pozostała wyłączona.'
