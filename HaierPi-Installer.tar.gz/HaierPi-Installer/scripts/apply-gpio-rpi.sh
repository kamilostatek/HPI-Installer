#!/usr/bin/env bash
# Replace only the Raspberry Pi GPIO adapter; never modify the NanoPi version.
set -Eeuo pipefail
ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
SOURCE="$ROOT_DIR/scripts/GPIO-rpi.py"
TARGET="${1:-/opt/haier/HPi/GPIO.py}"
[[ -f "$SOURCE" ]] || { echo 'BŁĄD: brak pliku GPIO-rpi.py.' >&2; exit 1; }
[[ -f "$TARGET" && ! -L "$TARGET" ]] || { echo "BŁĄD: brak zwykłego pliku $TARGET." >&2; exit 1; }
if cmp -s "$SOURCE" "$TARGET"; then
    echo 'Raspberry Pi: poprawka numeracji GPIO jest już zainstalowana.'
    exit 0
fi
BACKUP="${TARGET}.bak-haierpi-$(date -u +%Y%m%dT%H%M%SZ)-$$"
cp -p -- "$TARGET" "$BACKUP"
install -m 644 -- "$SOURCE" "$TARGET"
python3 -m py_compile "$TARGET"
echo "Raspberry Pi: ustawiono obsługę BCM GPIO -> sysfs z wykrywaniem bazy gpiochip. Kopia: $BACKUP"
