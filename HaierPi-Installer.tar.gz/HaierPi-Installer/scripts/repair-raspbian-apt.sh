#!/usr/bin/env bash
# Przy bledzie 404 podczas pobierania pakietow Raspbiana Bullseye
# zamienia WYŁĄCZNIE aktywne repozytoria Raspbiana na oficjalne archiwum.
# Nie modyfikuje repozytoriow Debiana, DietPi ani raspberrypi.org/debian.
set -Eeuo pipefail
IFS=$'\n\t'
[[ $EUID -eq 0 ]] || { echo '[APT] Wymagany administrator root.' >&2; exit 1; }
APT_ROOT="${HAIERPI_APT_ROOT:-/etc/apt}"
APT_GET="${HAIERPI_APT_GET:-apt-get}"
OS_RELEASE="${HAIERPI_OS_RELEASE:-/etc/os-release}"
BACKUP_PARENT="${HAIERPI_APT_BACKUP_DIR:-/root/haierpi-apt-backups}"
[[ -r "$OS_RELEASE" ]] || { echo '[APT] Brak /etc/os-release.' >&2; exit 1; }
# shellcheck disable=SC1090
source "$OS_RELEASE"
[[ "${VERSION_CODENAME:-${DEBIAN_CODENAME:-}}" == bullseye ]] || {
  echo '[APT] Naprawa dotyczy wyłącznie Raspbiana Bullseye. Nic nie zmieniono.' >&2
  exit 1
}
# Nie modyfikuj deb822 ani innych niestandardowych zrodel.
shopt -s nullglob
files=( "$APT_ROOT/sources.list" "$APT_ROOT"/sources.list.d/*.list )
changed_files=()
for file in "${files[@]}"; do
  [[ -f "$file" ]] || continue
  if grep -Eq '^[[:space:]]*deb[[:space:]]+(\[[^]]*\][[:space:]]+)?https?://raspbian\.raspberrypi\.(com|org)/raspbian/?[[:space:]]+bullseye([[:space:]]|$)' "$file"; then
    changed_files+=("$file")
  fi
done
if (( ${#changed_files[@]} == 0 )); then
  echo '[APT] Brak oficjalnego wpisu Raspbiana Bullseye do naprawienia. Repozytoria bez zmian.' >&2
  exit 1
fi
if compgen -G "$APT_ROOT/sources.list.d/*.sources" > /dev/null; then
  for file in "$APT_ROOT"/sources.list.d/*.sources; do
    if grep -Eq '^[[:space:]]*URIs:[[:space:]].*raspbian\.raspberrypi\.(com|org)' "$file"; then
      echo '[APT] Raspbian skonfigurowany jako deb822 (.sources); wymagana naprawa ręczna.' >&2
      exit 1
    fi
  done
fi
umask 077
mkdir -p "$BACKUP_PARENT"
backup="$BACKUP_PARENT/raspbian-$(date -u +%Y%m%dT%H%M%SZ)-$$"
mkdir -p "$backup"
for file in "${changed_files[@]}"; do
  rel="${file#"$APT_ROOT"/}"
  mkdir -p "$backup/$(dirname "$rel")"
  cp -a "$file" "$backup/$rel"
done
echo "[APT] Kopia oryginalnych repozytoriow Raspbiana: $backup"
restore() {
  local file rel
  for file in "${changed_files[@]}"; do
    rel="${file#"$APT_ROOT"/}"
    cp -a "$backup/$rel" "$file"
  done
}
for file in "${changed_files[@]}"; do
  temp=$(mktemp "${file}.tmp.XXXXXXXX")
  awk '
    /^[[:space:]]*deb[[:space:]]/ && /[[:space:]]bullseye([[:space:]]|$)/ {
      gsub(/https?:\/\/raspbian\.raspberrypi\.(com|org)\/raspbian\/?/, "http://archive.raspbian.org/raspbian")
    }
    { print }
  ' "$file" > "$temp"
  chmod --reference="$file" "$temp"
  chown --reference="$file" "$temp"
  mv -f "$temp" "$file"
done
report=$(mktemp)
trap 'rm -f "$report"' EXIT
if "$APT_GET" update -o APT::Update::Error-Mode=any > "$report" 2>&1; then
  echo '[APT] Zaktualizowano listy z oficjalnego archive.raspbian.org.'
else
  echo '[APT] Aktualizacja z archiwum nieudana; przywracam stare wpisy.' >&2
  tail -n 30 "$report" >&2
  restore
  exit 1
fi
