# Instalator HaierPi

Pakiet instalacyjny i serwisowy dla DietPi z Debianem 11 Bullseye (archiwalne repozytoria)
oraz wybranych zgodnych wersji Debiana. Sprzet: NanoPi NEO (Allwinner H3) i
Raspberry Pi Zero W / Zero 2 W. To wydanie jest testowe; NIE zostalo
uruchomione z podlaczona pompa ciepla na fizycznej plytce.

## Uruchomienie

Skopiuj archiwum na urzadzenie, rozpakuj je i uruchom:

    tar -xzf HaierPi-Installer.tar.gz
    cd HaierPi-Installer
    sudo bash install.sh

Dziala tez dotychczasowy tryb bez menu (wylacznie NOWA instalacja po ewentualnym usunieciu starej):

    sudo bash install.sh nanopi
    sudo bash install.sh rpi

## Menu

    Instalator HaierPi

    1. Pelna instalacja HaierPi na czystym systemie
    2. Konfiguracja UART i GPIO
    3. Konfiguracja temperatury zewnetrznej dla NanoPi
    4. Naprawa zaleznosci Python / pip
    5. Usun stara instalacje HaierPi, zachowaj config.ini
    6. Diagnostyka HaierPi (skrypt autora)
    7. Zakoncz

### 1. Pelna instalacja na czystym systemie

- Wybierasz NanoPi NEO lub Raspberry Pi Zero/Zero 2.
- Instalator sprawdza, czy root jest zapisywalny i czy /opt ma wystarczajaco miejsca.
- Na Bullseye probuje wykonac `apt update`; w razie typowych bledow 404 dla
  oficjalnych serwerow Debiana przenosi ich wpisy na archive.debian.org,
  z kopia /etc/apt. Nie wycofuje kontroli podpisow APT.
- Instaluje `python3`, `venv`, `pip` i zaleznosci systemowe, nastepnie
  zaleznosci Pythona z `requirements-pinned.txt` do `/opt/haier/env`.
- Po instalacji przez pip wymusza biblioteke `PyHaier` z dolaczonej paczki
  **1.4.5 Alpha13** w `/opt/haier/PyHaier` i w `venv/site-packages`.
  Zapobiega to pozostawieniu innej wersji po pip.
- Jezeli paczka HaierPi zawiera `app/bin`, kopiuje katalog razem z aplikacja.
  Po instalacji nadaje `chmod 755` plikom `/opt/haier/bin/dht22n`, `dht22r` i `dht22s`,
  gdy sa obecne (takze po naprawie bibliotek). Nie kompiluje ani nie pobiera
  osobnych binarek; aktualnie dolaczone archiwum nie zawiera katalogu `bin`.
  Brak plikow DHT22 nie ma znaczenia dla DS18B20.
- Kopiuje aplikacje do `/opt/haier` i tworzy bezpieczna konfiguracje, haslo
  administratora, sekret sesji oraz usluge `haier.service` (na poczatku wylaczona).
- Przy tworzeniu nowego konta pokazuje jednorazowo `Login: admin` oraz wybrane haslo
  na terminalu i czeka na Enter, by mozna je bylo zapisac. Haslo nie jest
  zapisywane jawnie do dziennika instalacji. Przy zachowanym `users.json` nie
  pokazuje poprzedniego hasla.
- Konfiguruje UART. Na RPi Zero W/Zero 2 W zwalnia PL011 poprzez wylaczenie
  Bluetooth; na NanoPi NEO wlacza UART1, jezeli obecny obraz ma overlay.
- NanoPi NEO pyta o DS18B20 na PA6 lub odczyt z Home Assistant.
- Raspberry Pi Zero W / Zero 2 W automatycznie włącza DS18B20 na GPIO4 (fizyczny pin 7):
  `dtoverlay=w1-gpio,gpiopin=4` i `[SETTINGS] outsidetemp=builtin`.
  Jednocześnie ustawia `enable_uart=1`, `dtoverlay=disable-bt` dla Modbus.`
- Nie uruchamia sterowania pompa przed restartem. Po skonfigurowaniu UART pyta, czy wlaczyc autostart uslugi. Odpowiedz T aktywuje `systemctl enable haier.service` (bez natychmiastowego uruchamiania); po restarcie usluga wystartuje automatycznie. Odpowiedz N pozostawi ja wylaczona.

### 2. Konfiguracja UART i GPIO

- Zatrzymuje i wylacza `haier.service` po jawnym potwierdzeniu bezpieczenstwa.
- NanoPi NEO: `modbusdev=/dev/ttyS1`, GPIO modbus=0, freqlimit=64,
  heatdemand=2, cooldemand=3, bindport=80.
- Raspberry Pi: `modbusdev=/dev/ttyAMA0`, GPIO modbus=17, freqlimit=27,
  heatdemand=22, cooldemand=10 (nie zmienia ustawionego portu WWW).
- Tworzy kopie `/opt/config.ini`, przygotowuje UART w plikach rozruchowych.
- Dla Raspberry Pi dodatkowo zapewnia 1-Wire GPIO4 i ustawia `outsidetemp=builtin`.
  Dla NanoPi pozostawia aktualne źródło temperatury bez zmian.
- Nie zmienia MQTT, danych HA ani harmonogramów.
- Wymagany jest restart przed uruchomieniem HaierPi. Po poprawnej zmianie mozna wlaczyc autostart (pytanie T/N).

### 3. Temperatura zewnetrzna (tylko NanoPi NEO)

- DS18B20: wlacza overlay 1-Wire PA6 z zalaczonego pliku DTBO i ustawia
  `[SETTINGS] outsidetemp = builtin`.
- Home Assistant: usuwa *jedynie* wpis `haierpi-w1-pa6` z `user_overlays`
  (jezeli byl aktywowany przez zestaw) i ustawia `outsidetemp = ha`.
- NanoPi nie modyfikuje overlayów Raspberry Pi. Raspberry Pi ma własną nakładkę
  `dtoverlay=w1-gpio,gpiopin=4` dodawaną przy konfiguracji UART/GPIO.
- Przed zmiana zatrzymuje usluge, tworzy kopie config.ini i boot config.
- Dla HA nalezy recznie podac adres, token i encje temperatury w `/opt/config.ini`.
- Weryfikuj dostepnosc DS18B20 po restarcie:

    ls /sys/bus/w1/devices/28-*

### Aktualizacja istniejącego HaierPi — osobno

Ta paczka **nie zawiera aktualizatora**. Aby zaktualizowac istniejaca
instalacje, wykorzystywany moze byc osobny skrypt autora:

    https://github.com/kamilostatek/hpi/blob/main/alpha13.sh

UWAGA: obecna wersja skryptu z GitHub usuwa katalogi `static` i `templates`
oraz `main.py` jeszcze przed pobraniem nowego archiwum, a kopie `config.ini`
wykonuje dopiero po podmianie kodu. Przed zastosowaniem na dzialajacym
sterowniku nalezy go poprawic (pobranie i kontrola archiwum PRZED usunieciem,
pelna kopia konfiguracji i plikow aplikacji oraz bezpieczna obsluga bledow).
Skrypt dodaje brakujace klucze konfiguracyjne, ale wymaga przegladu:
`restore_state_on_boot=1` oznacza przywrocenie poprzedniego stanu sterowania
po ponownym wlaczeniu, czego nie nalezy wymuszac bez zgody uzytkownika.

### 4. Naprawa zaleznosci Python / pip

- Zatrzymuje usluge po potwierdzeniu.
- Naprawia dostep do archiwalnych repozytoriow Bullseye, jesli to konieczne,
  doinstalowuje brakujace elementy Python/venv i ponownie instaluje wersje
  pakietow z `requirements-pinned.txt` w `/opt/haier/env`.
- Nastepnie przywraca `PyHaier` z paczki 1.4.5 Alpha13 jako ostatni etap
  zaleznosci oraz naprawia uprawnienia obecnych binarek DHT22.
- Uruchamia `pip check` i kontrole importow; nie zmienia `config.ini`,
  kodu aplikacji ani uslugi uruchamianej automatycznie.

### 5. Usun stara instalacje, zachowaj konfiguracje

Przeznaczone do migracji ze starej wersji HaierPi na **czysta instalacje**
Alpha13. Nie trzeba uruchamiac osobnego skryptu aktualizacji.

1. Instalator sprawdza **obie** lokalizacje pliku `config.ini`:
   `/opt/config.ini` oraz `/opt/haier/config.ini`.
2. Jezeli istnieje tylko jeden plik, wykorzysta go jako konfiguracje docelowa.
   Jesli istnieja oba, **pyta, ktory zachowac**, ale archiwizuje obydwa.
   Jesli nie istnieje zaden, usuwniecie zostaje anulowane.
3. Po potwierdzeniu stanu bezpiecznego pompy zatrzymuje znane uslugi HaierPi.
4. Tworzy prywatny katalog kopii `/var/backups/haierpi-clean-.../` i
   zachowuje oba znalezione `config.ini`, a takze `users.json` oraz
   `schedule_ch.json` i `schedule_dhw.json` (jezeli istnialy).
   Kopie danych pozostaja do odzyskania, ale nowa instalacja utworzy
   nowego administratora i czyste harmonogramy.
5. Wybrany plik konfiguracyjny zapisuje do **`/opt/config.ini`**.
   DOPISUJE jedynie brakujace sekcje i klucze Alpha13, zachowuje
   dotychczasowe wartosci i komentarze.
6. Dopiero po udanej migracji usuwa **wylacznie `/opt/haier`**.
   NIE usuwa calego `/opt`, repozytoriow APT ani systemowego Pythona.
7. Aby zainstalowac nowa aplikacje, wybierz opcje **1** w tym samym menu.
   Po instalacji instalator zapyta o autostart, jesli UART skonfigurowano poprawnie. Zweryfikuj UART i GPIO.

**Wazne:** jezeli masz stary, niestandardowy `config.ini`, instalator
automatycznie koryguje tylko ModbusDev i cztery wpisy GPIO do wybranej plytki; nie zmienia haseł ani innych ustawien sterowania.
Nieaktualne wpisy zostaja zachowane, a brakujace sa dopisane. Przed
wlaczeniem pompy sprawdz konfiguracje i parametr
`[SETTINGS] restore_state_on_boot`.

**Ograniczenia:** skrypt nie przenosi dowolnych prywatnych plikow
ze starego katalogu `/opt/haier` (poza wskazanymi wyzej).
Jezeli masz tam wlasne dane, zabezpiecz je oddzielnie przed usunieciem.
Nie usuwaj `/opt/haier` recznie przed wykonaniem opcji 5.

### 6. Diagnostyka HaierPi (offline)

- W paczce jest przesłany przez użytkownika `diagnostic.py` (kopia
  `/opt/haier/tools/diagnostic-original.py`) oraz ostrożniejsza wersja
  `/opt/haier/tools/diagnostics.py`, która sprawdza GPIO, pyta przed każdym
  przełączeniem i sprząta dostęp do pinów również po błędzie.
- Narzędzie `sudo haierpi-diagnostyka` instaluje się do
  `/usr/local/sbin/haierpi-diagnostyka` i **nie wymaga pobierania z Internetu**.
- Diagnostyka NIE uruchamia się podczas instalacji. Przed testami ostrzega,
  że sterowanie pompy zostanie zatrzymane i przekaźniki będą przełączane.
- Jeśli `haier.service` pracuje, użytkownik musi osobno zaakceptować
  zatrzymanie usługi. Po diagnostyce zostanie zapytany, czy uruchomić ją
  ponownie. Domyślnie NIE, ponieważ testy mogą dotyczyć aktywnej pompy.
- Opcja `--show-path` pokazuje lokalizację pliku; opcja `--update` nie pobiera
  już nowego skryptu z wiki. Aktualizacja dostarczana jest razem z kolejnym ZIP.
- **Uwaga:** wykonywanie testów na fizycznej pompie może być niebezpieczne,
  jeśli nie znasz biegunowości przekaźników i konfiguracji GPIO. Skrypt
  znormalizowano pod istniejące wartości NanoPi i RPi, ale nie testowano
  go na fizycznym sprzęcie.

### 7. Zakoncz

Zamyka menu bez modyfikacji plikow.

### Domyslne ustawienia 1.4.5 Alpha13

`configure.py` podczas **nowej instalacji** tworzy konfiguracje zawierajaca
wpisy Alpha13, m.in. CWU, strefy temperatur, ochrone przed legionella,
antifreeze, czasy testow oraz `ui_font`. Tryby sterowania i automatyczne
przywracanie stanu sa domyslnie wylaczone. Istniejacego `/opt/config.ini`
instalator nie nadpisuje.

## Uruchomienie sterowania po zmianach

Najpierw sprawdz `config.ini`, port UART oraz faktyczne polaczenia z przekaznikami.
Nie testuj dzialania z podlaczona pompa, dopoki polaryzacja wyjsc GPIO i tryb
pracy nie sa potwierdzone. Po zmianach w boot wymagany jest restart:

    sudo reboot

Po restarcie sprawdz port, stan systemu i logi:

    findmnt -no SOURCE,FSTYPE,OPTIONS /
    df -hT / /opt
    ls -l /dev/ttyS1       # NanoPi
    ls -l /dev/ttyAMA0     # RPi
    systemctl status haier.service --no-pager

Po weryfikacji mozna wlaczyc serwis za pomoca:

    cd HaierPi-Installer
    sudo bash enable-haierpi.sh

`enable-haierpi.sh` wymaga potwierdzenia T (tak) lub N (nie). Podczas instalacji mozesz wlaczyc autostart, ale dopiero po restarcie DietPi. Zawsze sprawdz wczesniej polaczenia GPIO i konfiguracje.

## Ograniczenia

- Debian 11 Bullseye ma zakonczone standardowe wsparcie LTS. Repozytoria
  archiwalne sluzy jedynie kompatybilnosci, nie sa aktualnym wsparciem
  bezpieczenstwa. Nie wystawiaj tego panelu bezposrednio do Internetu.
- Uzywane zaleznosci sa przypiete do starszego API. Nowe systemy z Pythonem
  poza wersjami 3.9-3.11 wymagaja oddzielnych testow kompatybilnosci.
- `HPi.GPIO` korzysta z historycznego interfejsu `/sys/class/gpio`; na
  nowym jadre moze byc niedostepny.
- Zmiany UART/DTBO wymagaja zgodnego jadra i bootloadera i nie zostaly
  przetestowane na kazdej wersji DietPi.
- Profil NanoPi NEO nie jest profilem NanoPi NEO2 / NEO3.
- Pliki z haslami i tokenami sa prywatne; nie publikuj obrazu systemu po
  konfiguracji kont i HA. Zawsze rob kopie karty przed zmianami.

## Status testow

Sprawdzono skladnie skryptow, menu, generowanie konfiguracji Alpha13 i
zachowanie istniejacego pliku konfiguracyjnego. Instalacja `apt`/`pip`, konfiguracja boot
oraz fizyczna praca na NanoPi NEO / Raspberry Pi wymagaja testu przed
publicznym wydaniem.

## Jezyk i potwierdzenia (v9)

Komunikaty instalatora sa po polsku. Potwierdzenia operacji maja format `[T/N]` (T = tak, N = nie); Enter oznacza NIE. Szczegolowe komunikaty dostarczane przez systemowe APT i pip moga pozostac w ich oryginalnym jezyku.

Po instalacji uruchamianie kontrolera dostepne jest przez polecenie `haierpi-wlacz` po sprawdzeniu UART, GPIO i bezpiecznego stanu pompy.

## Uruchomienie z GitHuba

Po zamieszczeniu instalatora i pliku SHA256 w GitHub Releases lub w glownym katalogu galezi main skopiuj `HaierPi-Installer.sh` do galezi main. Uruchamianie:

```bash
curl -fsSL https://raw.githubusercontent.com/kamilostatek/HPI-Installer/main/HaierPi-Installer.sh -o HaierPi-Installer.sh && bash HaierPi-Installer.sh
```

Potwierdzenia operacji: `[T/N]`. Enter albo N = anulowanie. Instalator nie uruchamia pompy natychmiast; przy włączonym autostarcie usługa może wystartować po restarcie.

## Poprawka v9.1

Usunięto próbę kopiowania pliku `README_HARMONOGRAM_TEMPERATURY.md`.
Jego brak nie wstrzymuje już instalacji. Wcześniej przerwaną instalację można usunąć opcją 5,
a następnie ponowić instalację opcją 1. Pozostała zawartość Alpha13 pozostaje bez zmian.

## Zmiany v9.2
- Wyszukiwanie UART1 w katalogach /boot/dtb-*/overlay (zgodnie z jadrem NanoPi NEO).
- Poprawione ustawienie temperatury zewnetrznej w zachowanym config.ini.
- Haslo administratora: minimum 4 znaki (ze wzgledow bezpieczenstwa zalecane haslo dluzsze).
- Usuniete komunikaty o Raspberry Pi i rezystorze z konfiguracji DS18B20 NanoPi.


### Automatyczne dopasowanie config.ini do plytki

Podczas pelnej instalacji (takze po usunieciu starej aplikacji) instalator sprawdza zachowany /opt/config.ini. W profilu NanoPi NEO poprawia [MAIN] modbusdev na /dev/ttyS1 oraz [GPIO] modbus=0, freqlimit=64, heatdemand=2, cooldemand=3. W profilu Raspberry Pi stosuje /dev/ttyAMA0 oraz numery GPIO 17, 27, 22, 10. Zmienia tylko piec ustawien sprzetowych, nie zmienia MQTT, hasel, harmonogramow ani innych wpisow. Przy zmianach tworzy kopie /opt/config.ini.bak-profil-*. Jezeli ustawienia sa poprawne, nie nadpisuje config.ini. Opcja menu 2 stosuje te same reguly i nie nadpisuje indywidualnego portu WWW. Nie jest to sprawdzenie fizycznego okablowania ani poprawnosci polaryzacji przekaznikow.

### Ponowne uruchomienie DietPi po pełnej instalacji

Po ukończeniu pełnej instalacji pojawia się pytanie `Czy chcesz teraz ponownie uruchomić DietPi? [T/N]:`. Odpowiedź `T` wykonuje restart, a `N` lub Enter pozostawia system uruchomiony. Restart jest potrzebny do aktywacji zmienionych nakładek UART i 1-Wire. Jeżeli wybrano autostart (T), usługa uruchomi się przy restarcie; przy N pozostanie wyłączona, aż do ręcznego włączenia poleceniem `haierpi-wlacz`.

## Autostart uslugi HaierPi

Po pelnej instalacji i poprawnej konfiguracji UART pojawia sie pytanie:

    Czy włączyć automatyczne uruchamianie HaierPi po restarcie? [T/N]:

T: `systemctl enable haier.service` - usluga bedzie startowac po restarcie, ale nie jest uruchamiana natychmiast.
N/Enter: usluga pozostaje wylaczona. Jesli UART nie zostal skonfigurowany, instalator nie proponuje autostartu.

Taki sam wybor wystepuje po udanej rekonfiguracji UART/GPIO, zmianie zrodla temperatury i naprawie zaleznosci, poniewaz te operacje zatrzymuja usluge.

Kontrola po restarcie:

    systemctl is-enabled haier.service
    systemctl is-active haier.service
    journalctl -u haier.service -b --no-pager -n 30

Uwaga: `enabled` oznacza autostart, a nie potwierdzenie poprawnej komunikacji z pompa. Przed zgoda T upewnij sie, ze GPIO, UART oraz stan przekaźnikow sa bezpieczne.


## Nowe repozytorium instalatora

Pliki dystrybucyjne sa publikowane w osobnym repozytorium:

    https://github.com/kamilostatek/HPI-Installer

W glownym katalogu galezi `main` umiesc trzy pliki:

    HaierPi-Installer.sh
    HaierPi-Installer.tar.gz
    HaierPi-Installer.tar.gz.sha256

Pobieranie jednym poleceniem:

```bash
curl -fsSL https://raw.githubusercontent.com/kamilostatek/HPI-Installer/main/HaierPi-Installer.sh -o HaierPi-Installer.sh && bash HaierPi-Installer.sh
```

Haslo administratora musi miec co najmniej 4 znaki. Login jest stale ustawiony na `admin`.
Tak krotkie haslo jest odpowiednie tylko do uzycia w zaufanej sieci lokalnej;
nie udostepniaj panelu HaierPi bezposrednio w Internecie.

## Czujnik DS18B20 na Raspberry Pi Zero W / Zero 2 W

Profil Raspberry Pi automatycznie przygotowuje `/boot/config.txt` albo
`/boot/firmware/config.txt` (w zależności od obrazu systemu):

```ini
[all]
enable_uart=1
dtoverlay=disable-bt
dtoverlay=w1-gpio,gpiopin=4
```

1-Wire jest na BCM GPIO4 (pin fizyczny 7); masa i 3.3V według schematu płytki.
Instalator nie dopisuje duplikatu istniejącego overlayu `w1-gpio`.
Jeżeli istniejący `w1-gpio` ma inny `gpiopin`, instalacja konfiguracji
rozruchowej zostanie przerwana zamiast próbować użyć dwóch pinów naraz.

W `config.ini` instalator ustawia `[SETTINGS] outsidetemp=builtin`, również gdy
konfiguracja pochodzi z wcześniejszej instalacji. Po zmianach wymagany restart.
Po restarcie sprawdź `ls /sys/bus/w1/devices/28-*` i działanie `/dev/ttyAMA0`.

NanoPi NEO pozostaje bez zmian: UART1 oraz `haierpi-w1-pa6` w `user_overlays`
po wybraniu fizycznego DS18B20; nie używa raspiowego `w1-gpio,gpiopin=4`.


## Poprawki migracji: Raspberry Pi GPIO i pakiety APT

- Tylko na Raspberry Pi instalator zastępuje `HPi/GPIO.py` adapterem korzystającym
  z numeracji BCM podanej w `config.ini` i wykrywającym faktyczny `base` kontrolera
  Broadcom w `/sys/class/gpio/gpiochip*/`. Dzięki temu GPIO17 poprawnie mapuje się
  również przy przesuniętej numeracji sysfs. Gdy nie można jednoznacznie wskazać
  kontrolera, adapter zgłasza błąd zamiast sterować niewłaściwym pinem.
- Na NanoPi NEO **nie modyfikuje** dotychczasowego `HPi/GPIO.py`.
- Ta sama poprawka dla RPi jest stosowana przy pełnej instalacji i przez
  opcję menu `2. Konfiguracja UART i GPIO`, po zatrzymaniu usługi.
- APT: oprócz dotychczasowych pakietów doinstalowywane są `pkg-config`,
  `libssl-dev`, `libffi-dev`, `liblzma-dev`, `zlib1g-dev`, `libbz2-dev`,
  `libreadline-dev` oraz `libsqlite3-dev`. Dotyczy instalacji i naprawy zależności.
- `PyHaier` pozostaje oryginalną wersją z 1.4.5 Alpha13 i jest przywracane
  po `pip`. Nie używamy biblioteki z ZIP-a migracji.
- Instalator **nie modyfikuje** SSH, SFTP ani innych usług sieciowych.
